package de.unimuenster.pi.bicycle;

import java.util.Map;
import java.util.logging.Logger;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;

public class Util {
    /**
     * Expose a JDK logger for injection. In order to save a bit more boiler
     * plate, the the class name is automatically set as logger category.
     * 
     */
    @Produces
    Logger getLogger(InjectionPoint ip) {
	String category = ip.getMember().getDeclaringClass().getName();
	return Logger.getLogger(category);
    }

    public static class Entry implements Map.Entry<BicycleArchetype, Integer> {
	private Integer value;
	private BicycleArchetype key;

	public Entry(BicycleArchetype key, Integer value) {
	    this.key = key;
	    this.value = value;
	}

	@Override
	public BicycleArchetype getKey() {
	    return key;
	}

	@Override
	public Integer getValue() {
	    return value;
	}

	public Integer getCount() {
	    return value;
	}

	@Override
	public Integer setValue(Integer value) {
	    this.value = value;
	    return value;
	}
	
	@Override
	public String toString() {
	    return "[key: "+key + " value "+value+"]";
	}

	public static void addBicycle(Map<Integer, Entry> map, BicycleArchetype archetype,
		int count) {
	    if (archetype == null)
		return;
	    Entry entry = map.get(archetype.getId());
	    if (entry == null)
		map.put(archetype.getId(), new Entry(archetype, count));
	    else
		entry.setValue(entry.getCount() + count);
	}

	/**
	 * removes Bicycle from Map and returns if to many
	 * @param map
	 * @param archetypeId
	 * @param count
	 * @return successfully removed bicycle
	 */
	public static boolean removeBicycle(Map<Integer, Entry> map, int archetypeId, int count) {
	    Entry entry = map.get(archetypeId);
	    int newValue = 0 - count;
	    if(entry != null) 
		newValue += entry.getCount();
	    if (newValue <= 0)
		map.remove(archetypeId);
	    else
		entry.setValue(newValue);
	    return newValue >= 0;
	}
    }
}
