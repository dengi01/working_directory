package de.unimuenster.pi.bicycle.ejb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import de.unimuenster.pi.bicycle.Util.Entry;
import de.unimuenster.pi.bicycle.jpa.Bicycle;
import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;
import de.unimuenster.pi.bicycle.jpa.Customer;
import de.unimuenster.pi.bicycle.jpa.Reservation;
import de.unimuenster.pi.bicycle.jpa.SearchArtefact;

/**
 * Session Bean implementation class ReservationServiceBean
 */
@Stateless
@LocalBean
public class ReservationServiceBean {

    @PersistenceContext
    private EntityManager em;

    // FIND Free Bikes
    // -------------------------------------------------------------

    /**
     * Search for bicycle archetypes that fit to the given search artefacts. Be
     * careful with order of params. null = any category/size/transmission
     * 
     * @param category
     * @param size
     * @param transmission
     * @return Collection with all archetypes that fit to corresponding search
     *         attributes
     */
    private Collection<BicycleArchetype> searchForArtefacts(SearchArtefact category,
	    SearchArtefact size, SearchArtefact transmission) {
	// query will be successively created
	String queryStr = "SELECT a FROM BicycleArchetype a";
	String condition = "";
	// no constraint
	if (category == null && size == null && transmission == null)
	    return em.createQuery(queryStr, BicycleArchetype.class).getResultList();

	// create constraint clause
	if (category != null)
	    condition = "(a.bicycleCategory = :category) ";
	if (size != null)
	    condition += (condition.length() > 0 ? "AND " : "") + "(a.size = :size) ";
	if (transmission != null)
	    condition += (condition.length() > 0 ? "AND " : "")
		    + "(a.transmission = :transmission) ";

	TypedQuery<BicycleArchetype> queryObj = em.createQuery(queryStr + " WHERE " + condition,
		BicycleArchetype.class);

	// Set only used parameter
	if (category != null)
	    queryObj = queryObj.setParameter("category", category);
	if (size != null)
	    queryObj = queryObj.setParameter("size", size);
	if (transmission != null)
	    queryObj = queryObj.setParameter("transmission", transmission);

	return queryObj.getResultList();
    }

    /**
     * Find all free bicycles that fit to the given reservation period
     * considering the given search constraints.
     * 
     * @param reservation
     * @param category
     * @param size
     * @param transmission
     * @return
     */
    public Collection<Bicycle> getPossibleBikes(Reservation reservation, SearchArtefact category,
	    SearchArtefact size, SearchArtefact transmission) {
	// get potential bicycle archetypes first
	Collection<BicycleArchetype> archetypes = searchForArtefacts(category, size, transmission);
	Collection<Bicycle> result = new ArrayList<Bicycle>();
	// get free bicycles for the found archetypes
	for (BicycleArchetype cur : archetypes)
	    result.addAll(getPossibleBikes(reservation, cur, -1));
	return result;
    }

    /**
     * find free bicycles of specified archetype. Free means bicycles that could
     * or are already part of the reservation.
     * 
     * @param reservation
     * @param archetype
     * @return All bicycles that are not part of another reservation during the
     *         used period. But bikes could be already added to this
     *         reservation.
     */
    public Collection<Bicycle> getPossibleBikes(Reservation reservation, BicycleArchetype archetype) {
	// no constraint concerning the number of bicycles to return.
	return getPossibleBikes(reservation, archetype, -1);
    }

    /**
     * find free bicycles of specified archetype. Free means bicycles that could
     * or are already part of the reservation.
     * 
     * @param reservation
     * @param archetype
     * @param max
     *            max number of returned bicycles. -1 if no restriction
     *            necessary
     * @return All bicycles that are not part of another reservation during the
     *         used period. But bikes could be already added to this
     *         reservation.
     */
    public Collection<Bicycle> getPossibleBikes(Reservation reservation,
	    BicycleArchetype archetype, int max) {

	Reservation resFromDB = getReservation(reservation.getId());
	// Get all bikes from that archetype and remove all occupied bikes
	// Find all bicycles of the specific archetype
	List<Bicycle> possibleBikes = em
		.createQuery("SELECT DISTINCT b FROM Bicycle b WHERE b.archetype = :archetype",
			Bicycle.class).setParameter("archetype", archetype).getResultList();
	// get occupied bicycles
	List<Bicycle> occupiedBikes = em
		.createQuery(
			"SELECT DISTINCT b FROM Bicycle b JOIN b.reservations r WHERE b.archetype = :archetype AND "
				+
				// NEW.FirstDay is within a reservation
				"((r.firstDay <= :firstDay and :firstDay <= r.lastDay) OR " +
				// NEW.LastDay is within a reservation
				"(r.firstDay <= :lastDay and :lastDay <= r.lastDay) OR " +
				// OLD.reservation is within the new reservation
				"(r.firstDay > :firstDay AND r.lastDay < :lastDay))", Bicycle.class)
		.setParameter("archetype", archetype)
		.setParameter("firstDay", reservation.getFirstDay())
		.setParameter("lastDay", reservation.getLastDay()).getResultList();

	// Only remove bicycles that are occupied by other reservations
	if (reservation.getId() > 0)
	    occupiedBikes.removeAll(resFromDB.getBicycles());

	possibleBikes.removeAll(occupiedBikes);
	if (possibleBikes.size() < max || max < 0)
	    max = possibleBikes.size();
	return possibleBikes.subList(0, max);
    }

    // - Persist and Merge methods -----------------------------------------------------------------

    /**
     * Creates a reservation with the given bicycles
     * 
     * @param reservation
     * @param orderedBicycles Collection of Tuples containing [Archetype,Number of bikes needed]
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void persistReservation(Reservation res, Collection<Entry> orderedBicycles)
	    throws EJBException {
	Reservation reservation = em.find(Reservation.class, res.getId());
	reservation.updateReservationWithValues(res);
	Collection<Bicycle> addToRes = new ArrayList<Bicycle>();
	// find bikes that should be added to the list
	for (Map.Entry<BicycleArchetype, Integer> entry : orderedBicycles) {
	    Collection<Bicycle> foundBikes = getPossibleBikes(reservation, entry.getKey(), entry.getValue());
	    if (foundBikes.size() < entry.getValue())
		throw new EJBException(new Exception("Not enough bicycles of type "
			+ entry.getKey().getName() + " available. Only " + foundBikes.size()
			+ " left."));
	    addToRes.addAll(foundBikes);
	}
	// if no Error occurred, reservation can be saved
	reservation.addBicycles(addToRes);
	em.persist(reservation);
    }

    /**
     * Updates a reservation to the bicycles in orderedBicycles. Deletes bikes
     * that are not anymore in the list.
     * 
     * @param res
     * @param orderedBicycles orderedBicycles Collection of Tuples containing [Archetype,Number of bikes needed]
     * @throws EJBException
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void mergeReservation(Reservation res, Collection<Entry> orderedBicycles)
	    throws EJBException {
	Reservation resFromDb = getReservation(res.getId());
	//Update reservation attributes that are not associated to other entities
	resFromDb.updateReservationWithValues(res);
	Collection<Bicycle> addToRes = new LinkedList<Bicycle>();
	Collection<Bicycle> removeFromRes = new LinkedList<Bicycle>();

	// Create a map of archID <Archetype,Count> for easier handling.
	Map<Integer, Entry> orderMap = new HashMap<Integer, Entry>();
	for (Entry entry : orderedBicycles) {
	    Entry.addBicycle(orderMap, entry.getKey(), entry.getCount());
	}
	// Remove bicycles that are already part of the reservation, they should
	// not be added again.
	for (Bicycle bike : resFromDb.getBicycles()) {
	    boolean removed = Entry.removeBicycle(orderMap, bike.getArchetype().getId(), 1);
	    if (!removed)
		removeFromRes.add(bike);
	}
	// get free bicycles and throw Exception if a problem occurs
	for (Entry entry : orderMap.values()) {
	    Collection<Bicycle> foundBikes = getPossibleBikes(resFromDb, entry.getKey(),
		    entry.getValue());
	    if (foundBikes.size() < entry.getValue())
		throw new EJBException(new Exception("Not enough bicycles of type "
			+ entry.getKey().getName() + " available. Only " + foundBikes.size()
			+ " left."));
	    addToRes.addAll(foundBikes);
	}
	// Finally remove missing bikes/bikes that should not be part of the reservation anymore
	for (Bicycle bike : removeFromRes)
	    res.removeBicycle(bike);
	// add new bikes
	res.addBicycles(addToRes);
	em.merge(res);
    }

    public void removeReservation(Reservation res) {
	Reservation reservation = em.find(Reservation.class, res.getId());
	if(reservation.isPaid()) {
	    em.remove(reservation);
	} else
	    throw new EJBException(new Exception("The reservation could not be deleted due to the payment status."));
	
    }
 
    //Simple get Methods to overcome detached object/lazy evaluation-Problems ---------------
    //---------------------------------------------------------------------------------------
    
    public Collection<Reservation> getReservationsForCustomer(Customer customer) {
	return em
		.createQuery("SELECT r FROM Reservation r WHERE r.customer = :customer",
			Reservation.class).setParameter("customer", customer).getResultList();
    }

    public Collection<Reservation> getReservationsForBicycle(Bicycle bike) {
	List<Reservation> result = em
		.createQuery(
			"Select distinct r FROM Reservation r join r.bicycles b where b.id = :id",
			Reservation.class).setParameter("id", bike.getId()).getResultList();
	return result;
    }

    public Collection<Reservation> getReservations() {
	return em.createQuery("SELECT r FROM Reservation r ORDER BY firstDay,LastDay",
		Reservation.class).getResultList();
    }

    public Collection<Bicycle> getBicyclesForReservation(Reservation reservation) {
	return em
		.createQuery(
			"SELECT b FROM Bicycle b JOIN b.reservations r WHERE r.id = :res_id "
				+ "ORDER BY b.archetype.id,b.serialNumber", Bicycle.class)
		.setParameter("res_id", reservation.getId()).getResultList();
    }

    public Map<BicycleArchetype, Long> getArchetypesAndQuantityForReservation(
	    Reservation reservation) {
	@SuppressWarnings("unchecked")
	List<Object[]> result_tmp = em
		.createQuery(
			"SELECT a,COUNT(a) FROM Reservation r JOIN r.bicycles b JOIN b.archetype a"
				+ " WHERE r.id = :res_id GROUP BY a")
		.setParameter("res_id", reservation.getId()).getResultList();
	Map<BicycleArchetype, Long> result = new HashMap<BicycleArchetype, Long>();
	for (Object[] tmp : result_tmp) {
	    if (tmp[0] != null) {
		BicycleArchetype key = (BicycleArchetype) tmp[0];
		Long value = (Long) (tmp[1] != null ? tmp[1] : 0l);
		result.put(key, value);
	    }
	}
	return result;
    }

    public Reservation getReservation(int id) {
	return em.find(Reservation.class, id);
    }

}
