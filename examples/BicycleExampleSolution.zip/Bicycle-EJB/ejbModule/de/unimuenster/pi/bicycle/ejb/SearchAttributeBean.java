package de.unimuenster.pi.bicycle.ejb;

import java.util.Collection;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.bicycle.jpa.SearchArtefact;
import de.unimuenster.pi.bicycle.jpa.SearchCategory;

@Stateless
@LocalBean
public class SearchAttributeBean {
	
	@PersistenceContext
	EntityManager em;
	
	public SearchArtefact getSearchArtefact(int id) {
		return em.find(SearchArtefact.class, id);
	}
	
	public SearchArtefact createSearchArtefact(SearchArtefact artefact) {
		em.persist(artefact);
		return em.find(SearchArtefact.class, artefact.getId());
	}
	
	public SearchArtefact mergeSearchArtefact(SearchArtefact artefact) {
		em.merge(artefact);
		return em.find(SearchArtefact.class, artefact.getId());
	}
	
	public void deleteSearchArtefact(SearchArtefact artefact) throws EJBException {
		artefact = em.find(SearchArtefact.class, artefact.getId());
		int countBicycles = em.createQuery("SELECT DISTINCT ba FROM BicycleArchetype ba WHERE ba.size = :a OR ba.transmission = :a OR ba.bicycleCategory = :a").setParameter("a", artefact).getResultList().size();
		if(countBicycles > 0) {
			throw new EJBException("Search artefacts could not be deleted due to usage of this object.");
		} else
			em.detach(artefact);
	}
	
	public Collection<SearchArtefact> getSearchArtefacts(SearchCategory category) {
		return em.createQuery("FROM SearchArtefact WHERE category = :c",SearchArtefact.class)
				.setParameter("c", category).getResultList();
	}
	
	public Collection<SearchArtefact> getSearchArtefacts() {
		return em.createQuery("FROM SearchArtefact ORDER BY category",SearchArtefact.class)
				.getResultList();
	}
}
