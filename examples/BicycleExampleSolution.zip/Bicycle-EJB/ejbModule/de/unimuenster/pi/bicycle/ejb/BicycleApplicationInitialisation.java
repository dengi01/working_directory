package de.unimuenster.pi.bicycle.ejb;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.management.timer.Timer;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.bicycle.jpa.Bicycle;
import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;
import de.unimuenster.pi.bicycle.jpa.Customer;
import de.unimuenster.pi.bicycle.jpa.Employee;
import de.unimuenster.pi.bicycle.jpa.Reservation;
import de.unimuenster.pi.bicycle.jpa.SearchArtefact;
import de.unimuenster.pi.bicycle.jpa.SearchCategory;
import de.unimuenster.pi.bicycle.jpa.User;

/**
 * Session Bean implementation class BicycleApplicationInitialisation
 */
@Singleton
@Startup
public class BicycleApplicationInitialisation {

    @PersistenceContext
    private EntityManager em;

    @SuppressWarnings("deprecation")
    @PostConstruct
    public void Initialisation() {
	String artefact_query = "SELECT a FROM SearchArtefact a WHERE a.category LIKE :category";

	// Are there any bicycle categories?
	if (em.createQuery(artefact_query)
		.setParameter("category", SearchCategory.BICYCLE_CATEGORY).getResultList().size() <= 0) {
	    em.persist(new SearchArtefact("Pedelec", SearchCategory.BICYCLE_CATEGORY));
	    em.persist(new SearchArtefact("Mountain Bike", SearchCategory.BICYCLE_CATEGORY));
	    em.persist(new SearchArtefact("City Bike", SearchCategory.BICYCLE_CATEGORY));
	    em.persist(new SearchArtefact("Touring Bike", SearchCategory.BICYCLE_CATEGORY));
	}

	if (em.createQuery(artefact_query).setParameter("category", SearchCategory.TRANSMISSION)
		.getResultList().size() <= 0) {
	    em.persist(new SearchArtefact("Hub Gear", SearchCategory.TRANSMISSION));
	    em.persist(new SearchArtefact("Derailleur Gears", SearchCategory.TRANSMISSION));
	}
	if (em.createQuery(artefact_query).setParameter("category", SearchCategory.SIZE)
		.getResultList().size() <= 0) {
	    em.persist(new SearchArtefact("26-inch", SearchCategory.SIZE));
	    em.persist(new SearchArtefact("28-inch", SearchCategory.SIZE));
	}

	if (em.createQuery("FROM BicycleArchetype").getResultList().size() <= 0) {
	    BicycleArchetype bicArch1,bicArch2;
	    Bicycle bike1,bike2,bike3;
	    SearchArtefact size1 = em.createQuery(artefact_query,SearchArtefact.class)
		    .setParameter("category", SearchCategory.SIZE).getResultList().get(0);
	    SearchArtefact size2 = em.createQuery(artefact_query,SearchArtefact.class)
		    .setParameter("category", SearchCategory.SIZE).getResultList().get(1);
	    SearchArtefact transmission = em.createQuery(artefact_query,SearchArtefact.class)
		    .setParameter("category", SearchCategory.TRANSMISSION).getResultList().get(1);
	    SearchArtefact category = em.createQuery(artefact_query,SearchArtefact.class)
		    .setParameter("category", SearchCategory.BICYCLE_CATEGORY).getResultList().get(0);
	    
	    bicArch1 = new BicycleArchetype();
	    bicArch1.setName("E-Bike small");
	    bicArch1.setDescription("Small bicycle with electric drive");
	    bicArch1.setSize(size1);
	    bicArch1.setTransmission(transmission);
	    bicArch1.setBicycleCategory(category);
	    bicArch1.setPrice(5);
	    em.persist(bicArch1);

	    bike1 = new Bicycle();
	    bike1.setArchetype(bicArch1);
	    bike1.setSerialNumber("E-Bike1");
	    em.persist(bike1);
	    
	    bike2 = new Bicycle();
	    bike2.setArchetype(bicArch1);
	    bike2.setSerialNumber("E-Bike2");
	    em.persist(bike2);
	    
	    bicArch2 = new BicycleArchetype();
	    bicArch2.setName("E-Bike tall");
	    bicArch2.setDescription("Tall bicycle with electric drive");
	    bicArch2.setSize(size2);
	    bicArch2.setTransmission(transmission);
	    bicArch2.setBicycleCategory(category);
	    bicArch2.setPrice(6);
	    em.persist(bicArch2);
	    
	    bike3 = new Bicycle();
	    bike3.setArchetype(bicArch2);
	    bike3.setSerialNumber("E-Bike3");
	    em.persist(bike3);

	    Customer customer = new Customer("customer", "customer", "John", "Doe",
		    "Hester Street", "Manhattan", "12345");
	    em.persist(customer);
	    Date date1 = new Date(112, 5, 5, 2, 0); //2012-06-05 CEST
	    Date date2 = new Date(date1.getTime() + 1L * Timer.ONE_WEEK);
	    Date date3 = new Date(date2.getTime() + 1L * Timer.ONE_DAY);
	    Date date4 = new Date(date3.getTime() + 2L * Timer.ONE_DAY);
	    
	    Reservation res = new Reservation(customer, date1, date2);
	    res.addBicycle(bike1);
	    em.persist(res);

	    Reservation res2 = new Reservation(customer, date3, date4);
	    res2.addBicycle(bike1);
	    res2.addBicycle(bike3);
	    res2.setPayDay(new Date(112, 5, 1));

	    em.persist(res2);
	}

	if (em.createQuery("SELECT u FROM User u WHERE u.username like :username", User.class)
		.setParameter("username", "admin").getResultList().size() <= 0) {
	    em.persist(new Employee("admin", "admin", "Admin", "Istrator"));
	}

    }
}
