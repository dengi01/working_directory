package de.unimuenster.pi.bicycle.ejb;

import java.util.Collection;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.bicycle.jpa.Bicycle;
import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;

@Stateless
public class BicycleServiceBean {

	@PersistenceContext
	private EntityManager em;

	public Collection<Bicycle> getBicycleOfArchetype(BicycleArchetype m) {
		return em
				.createQuery("FROM Bicycle c WHERE c.archetype=:m",
						Bicycle.class).setParameter("m", m).getResultList();
	}

	public Bicycle createBicycle(BicycleArchetype m, String serialNumber) {
		Bicycle result = new Bicycle();
		result.setArchetype(m);
		result.setSerialNumber(serialNumber);
		return createBicycle(result);
	}

	public Bicycle createBicycle(Bicycle newBike) {
		newBike.setArchetype(em.find(BicycleArchetype.class, newBike
				.getArchetype().getId()));
		em.persist(newBike);
		return em.find(Bicycle.class, newBike.getId());
	}

	public Bicycle getBicycle(int inventoryNo) {
		return em.find(Bicycle.class, inventoryNo);
	}

}
