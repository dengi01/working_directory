package de.unimuenster.pi.bicycle.ejb;
import java.util.Collection;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;

@Stateless
public class BicycleArchetypeServiceBean {
	@PersistenceContext
	private EntityManager em;

	public BicycleArchetype createBicycleArchetype(BicycleArchetype archetype) {
		em.persist(archetype);
		return archetype;
	}
	
	public BicycleArchetype mergeBicycleArchetype(BicycleArchetype archetype) {
		em.merge(archetype);
		return archetype;
	}

	public BicycleArchetype getBicycleArchetype(int archetypeId) {
		BicycleArchetype archetype = em.find(BicycleArchetype.class, archetypeId);
		if (archetype == null)
			throw new IllegalArgumentException(String.format(
					"Bicycle archetype with ID %s not found", archetypeId));
		return archetype;
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Collection<BicycleArchetype> getAllBicycleArchetypes() {
		return em.createQuery("FROM BicycleArchetype", BicycleArchetype.class).getResultList();
	}
}
