package de.unimuenster.pi.bicycle.ejb;

import java.util.Collection;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.ConstraintViolationException;

import de.unimuenster.pi.bicycle.jpa.Customer;
import de.unimuenster.pi.bicycle.jpa.Employee;
import de.unimuenster.pi.bicycle.jpa.Reservation;
import de.unimuenster.pi.bicycle.jpa.User;

@Stateless
@LocalBean
public class UserServiceBean {
	
	@PersistenceContext
	private EntityManager em;
	
//	@Inject
//	Logger log;
	
	public Collection<User> getUsers() {
		Collection<User> result = em.createQuery("SELECT u FROM User u" ,User.class).getResultList();
		return result;
	}
	
	public Collection<Customer> getCustomer() {
	    return em.createQuery("FROM Customer", Customer.class).getResultList();
	}
	
	public User login(String username,String password) {
		@SuppressWarnings("unchecked")
		Collection<User> list = em.createQuery("SELECT u FROM User u WHERE u.username = :username AND u.password = :password").setParameter("username", username).setParameter("password", password).getResultList();
		if (list.size()<=0 || list.size() > 1) {
			return null;
		}
		return list.iterator().next();
	}
	
	public User findUserById(int id) {
		return em.find(User.class, id);
	}
	
	public Customer createCustomer(Customer customer) {
	    return (Customer) createUser(customer);
	}
	
	public User mergeUser(User user) {
	    if(usernameExists(user.getUsername(),user.getId()))
		throw new EJBException(new ConstraintViolationException("Username is already in use!",null));
	    em.merge(user);
	    return em.find(User.class, user.getId());
	}
	public boolean usernameExists(String username, int id) {
	    return em.createQuery("FROM User u WHERE u.username = :username AND u.id != :id", User.class).setParameter("username", username).setParameter("id", id).getResultList().size() > 0;
	}
	public void removeUser(User u) {
	    User user = em.find(User.class, u.getId());
	    if(user instanceof Customer) {
		Customer customer = (Customer) user;
		for(Reservation r : customer.getReservations())
		    if(!r.isPaid()) {
			throw new EJBException(new ConstraintViolationException("There are still unpaid reservations ["+r.getId()+"]!",null));
		    }
		em.remove(user);
	    }
	    if(user instanceof Employee)
		em.remove(user);
	}
	
	public User createUser(User user) {
	    if(usernameExists(user.getUsername(),0))
		throw new EJBException(new ConstraintViolationException("Username is already in use!",null));
	    em.persist(user);
	    return em.find(User.class, user.getId());
	}
	

}
