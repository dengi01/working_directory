package de.unimuenster.pi.bicycle.web;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.persistence.EntityManager;

import de.unimuenster.pi.bicycle.jpa.SearchArtefact;

/**
 * This converter is needed to convert selected SearchArtefacts which are
 * selected in views back to java objects. JSF pages present strings only and no
 * objects. Therefore a converter is needed to convert string representations
 * back to objects.
 * 
 * @author c_usen01
 * 
 */
@FacesConverter(value = "SearchArtefactConverter")
public class SearchArtefactConverter implements Converter {

	// no @PersistenceContext possible since injection works for EJBs only and
	// not for faces converter. To use the entity manager it is passed over by
	// the bean.
	EntityManager em;

	public SearchArtefactConverter(EntityManager em) {
		this.em = em;
	}

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
		if (arg2 == null)
			return null;
		try {
			int id = Integer.parseInt(arg2);
			em.clear();
			SearchArtefact artefact = em.find(SearchArtefact.class, id);

			return artefact;
		} catch (NumberFormatException e) {
		    //No Selection
		    return null;
		}
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {
		if (arg2 == null || !(arg2 instanceof SearchArtefact))
			return null;
		return ((SearchArtefact) arg2).getId() + "";
	}

}
