package de.unimuenster.pi.bicycle.web.beans;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.bicycle.ejb.UserServiceBean;
import de.unimuenster.pi.bicycle.jpa.Customer;
import de.unimuenster.pi.bicycle.jpa.User;
import de.unimuenster.pi.bicycle.web.CustomerConverter;

@ManagedBean(name = "listUsers")
@RequestScoped
public class ListUsers {

    @ManagedProperty(value = "#{login}")
    private Login loginBean;

    public void setLoginBean(Login loginBean) {
	this.loginBean = loginBean;
    }

    @PersistenceContext
    EntityManager em;

    @Inject
    Logger log;

    @EJB
    UserServiceBean userEjb;

    public ListUsers() throws IOException {

    }

    public Collection<User> getUsers() {
	if (loginBean.isCustomer()) {
	    return new ArrayList<User>();
	}
	return userEjb.getUsers();
    }

    public Collection<Customer> getCustomers() {
	if (loginBean.isCustomer()) {
	    return new ArrayList<Customer>();
	}
	return userEjb.getCustomer();
    }

    public CustomerConverter getCustomerConverter() {
	return new CustomerConverter(em);
    }
}
