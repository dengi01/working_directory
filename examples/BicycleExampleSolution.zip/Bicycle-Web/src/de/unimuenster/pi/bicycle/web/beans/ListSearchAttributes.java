package de.unimuenster.pi.bicycle.web.beans;

import java.util.Collection;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import de.unimuenster.pi.bicycle.ejb.SearchAttributeBean;
import de.unimuenster.pi.bicycle.jpa.SearchArtefact;
import de.unimuenster.pi.bicycle.jpa.SearchCategory;
import de.unimuenster.pi.bicycle.web.Util;

@ManagedBean(name="listSearchAttributes")
@ViewScoped
public class ListSearchAttributes {
	
	@EJB
	SearchAttributeBean searchArtefactEjb;
	
	Collection<SearchArtefact> searchArtefacts;
	
	SearchArtefact searchArtefact;
	int id;
	
	public Collection<SearchArtefact> getSearchArtefacts() {
		if (searchArtefacts == null) {
			searchArtefacts = searchArtefactEjb.getSearchArtefacts();
		}
		return searchArtefacts;
	}
	
	public void setId(int id) {
		
		searchArtefact = searchArtefactEjb.getSearchArtefact(id);
		if(searchArtefact != null) {
			this.id = id;
		} else	{
			this.id = 0;
			searchArtefact = new SearchArtefact();
			}
	}
	
	public int getId() {return id;}

	public SearchArtefact getSearchArtefact() {
		if (searchArtefact == null) {
			searchArtefact = new SearchArtefact();
			this.id = 0;
		}
		return searchArtefact;
	}
	
	public String persist() {
		try {
			searchArtefact = searchArtefactEjb.createSearchArtefact(searchArtefact);
			FacesContext.getCurrentInstance().addMessage(null, Util.successMessage("Search Attribute succesfully created."));
			id = searchArtefact.getId();
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null, Util.errorMessage("Search attribute was not created."));
			searchArtefact.setId(this.id);
		}
		return null;
	}
	
	public String merge() {
		try {
			searchArtefactEjb.mergeSearchArtefact(searchArtefact);
			FacesContext.getCurrentInstance().addMessage(null, Util.successMessage("Search Attribute succesfully saved."));
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null, Util.errorMessage("Search attribute was not saved."));
		}
		return null;
	}
	
	public boolean isNewAttribute() {
		return getSearchArtefact().getId() == 0;
	}
	
	public SearchCategory[] getSearchCategories() {
		return SearchCategory.values();
	}
	
	public String delete() {
		try {
			searchArtefact = searchArtefactEjb.getSearchArtefact(searchArtefact.getId());
			searchArtefactEjb.deleteSearchArtefact(searchArtefact);
			FacesContext.getCurrentInstance().addMessage(null, Util.successMessage(searchArtefact.getName() + " successfully deleted."));
			searchArtefact = new SearchArtefact();
		} catch (EJBException e) {
			FacesContext.getCurrentInstance().addMessage(null, Util.errorMessage(searchArtefact.getName() + " not deleted."));
			e.printStackTrace();
		}
		
		return null;
	}
}
