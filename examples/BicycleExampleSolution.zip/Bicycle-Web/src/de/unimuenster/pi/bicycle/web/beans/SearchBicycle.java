package de.unimuenster.pi.bicycle.web.beans;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.bicycle.ejb.BicycleArchetypeServiceBean;
import de.unimuenster.pi.bicycle.ejb.ReservationServiceBean;
import de.unimuenster.pi.bicycle.ejb.SearchAttributeBean;
import de.unimuenster.pi.bicycle.jpa.Bicycle;
import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;
import de.unimuenster.pi.bicycle.jpa.Customer;
import de.unimuenster.pi.bicycle.jpa.Reservation;
import de.unimuenster.pi.bicycle.jpa.SearchArtefact;
import de.unimuenster.pi.bicycle.jpa.SearchCategory;
import de.unimuenster.pi.bicycle.web.SearchArtefactConverter;
import de.unimuenster.pi.bicycle.web.Util;
import de.unimuenster.pi.bicycle.Util.Entry;

@ViewScoped
@ManagedBean(name = "searchBicycle")
public class SearchBicycle implements Serializable {
    // implements Serializable to save viewScoped Bean
    private static final long serialVersionUID = 1L;

    @PersistenceContext
    EntityManager em;

    @EJB
    private SearchAttributeBean searchArtefactEjb;
    @EJB
    private ReservationServiceBean reservationEjb;
    @EJB
    private BicycleArchetypeServiceBean archetypeEjb;

    @ManagedProperty(value = "#{login}")
    private Login loginBean;

    // Method needed for @ManagedProperty
    public void setLoginBean(Login loginBean) {
	this.loginBean = loginBean;
    }

    @Inject
    private Logger log;

    // Map for easier handling of bicycles --> Key = ArchetypeID Value =
    // [Archetype,Number of Bikes]
    private Map<Integer, Entry> bicyclesToOrder = new HashMap<Integer, Entry>();

    private Map<Integer, Entry> availableBicycles;

    private Reservation res;

    private SearchArtefact size;
    private SearchArtefact transmission;
    private SearchArtefact category;

    public void setId(Integer id) {
	Reservation tmp = reservationEjb.getReservation(id);
	if (loginBean.isEmployee() && tmp != null) {
	    setReservation(tmp);
	} else if (loginBean.isCustomer() && tmp != null && tmp.getCustomer() != null
		&& loginBean.getCurrentUser().getId() == tmp.getCustomer().getId())
	    setReservation(tmp);
	else
	    setReservation(new Reservation());
    }

    public Integer getId() {
	return null; // Prevent to set ID in every request
    }

    //initialize reservation attribute
    private void setReservation(Reservation res) {
	if (loginBean.isCustomer()) {
	    if (res.getCustomer() != null
		    && res.getCustomer().getId() != loginBean.getCurrentUser().getId()) {
		FacesContext.getCurrentInstance().addMessage(
			null,
			Util.errorMessage("You are not allowed to view this reservation [id: "
				+ res.getId() + "]"));
		res = new Reservation();
	    }
	    if (res.getCustomer() == null)
		res.setCustomer((Customer) loginBean.getCurrentUser());
	    this.res = res;
	} else if (loginBean.isEmployee())
	    this.res = res;
	else
	    this.res = new Reservation();
	// Set first values
	size = transmission = category = null;
	availableBicycles = null;
	bicyclesToOrder = new HashMap<Integer, Entry>();
	for (Bicycle bike : res.getBicycles()) {
	    Entry.addBicycle(bicyclesToOrder, bike.getArchetype(), 1);
	}
    }

    public String addBicycle(int archetypeId) {
	availableBicycles = null; // keep available bikes up to date //// reset at
				  // the begin of every action

	BicycleArchetype tmp = archetypeEjb.getBicycleArchetype(archetypeId);
	//Prevent adding of not existing archetypes
	if (tmp == null) {
	    FacesContext.getCurrentInstance().addMessage(null,
		    Util.errorMessage("Request could not be executed"));
	    return null;
	}
	Entry.addBicycle(bicyclesToOrder, tmp, 1);
	log.info("Add Bicycle with Archetype id = " + tmp.getId());
	return null;
    }

    public String removeBicycle(int id) {
	log.info("Remove bicycle with archetype id: " + id);
	availableBicycles = null; // keep available bikes up to date
	Entry.removeBicycle(bicyclesToOrder, id, 1);
	return null;
    }

    public String refresh() {
	availableBicycles = null;
	log.info(res.toString());
	return null;
    }

    public String persist() {
	if (res.getId() != 0)
	    return merge();
	log.info("persist reservation executed" + res);
	try {
	    reservationEjb.persistReservation(res, bicyclesToOrder.values());
	    FacesContext.getCurrentInstance().addMessage(null,
		    Util.successMessage("Reservation is saved successfully."));
	    setId(res.getId());
	} catch (EJBException e) {
	    FacesContext.getCurrentInstance().addMessage(null,
		    Util.errorMessage(Util.getConstraintMessage(e)));
	}
	return null;
    }

    public String merge() {
	try {
	    log.info("merge reservation executed" + res);
	    reservationEjb.persistReservation(res, bicyclesToOrder.values());
	    FacesContext.getCurrentInstance().addMessage(null,
		    Util.successMessage("Reservation is saved successfully."));
	    setId(res.getId());
	} catch (EJBException e) {
	    FacesContext.getCurrentInstance().addMessage(null,
		    Util.errorMessage(Util.getConstraintMessage(e)));
	}
	return null;
    }

    public List<Map.Entry<BicycleArchetype, Integer>> getAvailableBicycles() {
	// Return empty List if a date is missing.
	if (res.getFirstDay() == null || res.getLastDay() == null
		|| res.getLastDay().before(res.getFirstDay())) {
	    availableBicycles = null;
	    return Util.idMapToList(null);
	}
	// if calculated return list
	if (availableBicycles != null)
	    return Util.idMapToList(availableBicycles);

	log.info("Calc available Bicycles from DB.");
	availableBicycles = new HashMap<Integer, Entry>();
	Collection<Bicycle> bikes = reservationEjb.getPossibleBikes(res, category, size,
		transmission);
	// Add free available bikes to list
	for (Bicycle bike : bikes) {
	    Entry.addBicycle(availableBicycles, bike.getArchetype(), 1);
	}
	// remove already added bikes
	for (int archetypeId : bicyclesToOrder.keySet()) {
	    int count = bicyclesToOrder.get(archetypeId).getCount();
	    if (availableBicycles.get(archetypeId) != null) {
		Entry.removeBicycle(availableBicycles, archetypeId, count);
	    }
	}
	return Util.idMapToList(availableBicycles);
    }

    public Reservation getReservation() {
	if (res == null)
	    setReservation(new Reservation());
	return res;
    }

    public SearchArtefact getSize() {
	return size;
    }

    public void setSize(SearchArtefact size) {
	this.size = size;
    }

    public SearchArtefact getTransmission() {
	return transmission;
    }

    public void setTransmission(SearchArtefact transmission) {
	this.transmission = transmission;
    }

    public SearchArtefact getCategory() {
	return category;
    }

    public void setCategory(SearchArtefact category) {
	this.category = category;
    }

    public Collection<SearchArtefact> getSearchArtefacts(SearchCategory category) {
	return searchArtefactEjb.getSearchArtefacts(category);
    }

    public List<Map.Entry<BicycleArchetype, Integer>> getBicyclesToOrder() {
	return Util.idMapToList(bicyclesToOrder);
    }

    public Converter getSearchArtefactConverter() {
	return new SearchArtefactConverter(em);
    }

    public int getPrice() {
	int result = 0;
	for (Entry entry : bicyclesToOrder.values())
	    result += entry.getKey().getPrice() * entry.getCount() * res.getCountDays();
	return result;
    }
}
