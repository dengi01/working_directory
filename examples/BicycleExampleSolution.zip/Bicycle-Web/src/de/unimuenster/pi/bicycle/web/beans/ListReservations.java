package de.unimuenster.pi.bicycle.web.beans;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import de.unimuenster.pi.bicycle.ejb.ReservationServiceBean;
import de.unimuenster.pi.bicycle.jpa.Bicycle;
import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;
import de.unimuenster.pi.bicycle.jpa.Customer;
import de.unimuenster.pi.bicycle.jpa.Reservation;
import de.unimuenster.pi.bicycle.web.Util;

@RequestScoped
@ManagedBean(name = "listReservations")
public class ListReservations {

    @EJB
    private ReservationServiceBean reservationEjb;

    @ManagedProperty(value = "#{login}")
    private Login loginBean;

    public void setLoginBean(Login loginBean) {
	this.loginBean = loginBean;
    }

    Collection<Reservation> reservations;

    public Collection<Reservation> getReservations() {
	if (reservations == null) {
	    if (loginBean.isCustomer())
		reservations = reservationEjb.getReservationsForCustomer((Customer) loginBean
			.getCurrentUser());
	    else if (loginBean.isEmployee())
		reservations = reservationEjb.getReservations();
	}
	return reservations;
    }

    public String deleteReservation(int id) {
	try {
	    Reservation res = reservationEjb.getReservation(id);
	    if (loginBean.isCustomer() && res.getCustomer().getId() == loginBean.getCurrentUser().getId() ||
		    loginBean.isEmployee()) {
		    reservationEjb.removeReservation(res);
		    FacesContext.getCurrentInstance().addMessage(null,
			    Util.errorMessage("Deletion successful."));
		    reservations = null;
	    }
	    else 
		FacesContext.getCurrentInstance().addMessage(null,
			    Util.errorMessage("You are not allowed to delete this reservation"));
	} catch (EJBException e) {
	    FacesContext.getCurrentInstance().addMessage(null,
		    Util.errorMessage(Util.getConstraintMessage(e)));
	}
	return null;
    }

    public List<Map.Entry<BicycleArchetype, Long>> getArchetypeAmountMap(Reservation reservation) {
	if (reservation == null)
	    return Util.mapToList(new HashMap<BicycleArchetype, Long>());
	return Util.mapToList(reservationEjb.getArchetypesAndQuantityForReservation(reservation));
    }

    public Collection<Bicycle> getBicyclesForReservation(Reservation reservation) {
	return reservationEjb.getBicyclesForReservation(reservation);
    }
}
