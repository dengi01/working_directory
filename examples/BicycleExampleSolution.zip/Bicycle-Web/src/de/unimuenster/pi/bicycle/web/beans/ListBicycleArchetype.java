package de.unimuenster.pi.bicycle.web.beans;

import java.util.Collection;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;

import de.unimuenster.pi.bicycle.ejb.BicycleArchetypeServiceBean;
import de.unimuenster.pi.bicycle.ejb.BicycleServiceBean;
import de.unimuenster.pi.bicycle.jpa.Bicycle;
import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;


@ManagedBean(name="listBicycleArchetype")
public class ListBicycleArchetype {
	@EJB
	private BicycleArchetypeServiceBean ejb;
	
	@EJB
	private BicycleServiceBean bikeEjb;
	
	private Collection<BicycleArchetype> archetypes;
	
	public Collection<BicycleArchetype> getArchetypes(){
		if(archetypes == null)
			archetypes = ejb.getAllBicycleArchetypes();
		return archetypes;
	}
	
	public Collection<Bicycle> getBicycles(BicycleArchetype archetype) {
		return bikeEjb.getBicycleOfArchetype(archetype);
	}
}
