package de.unimuenster.pi.bicycle.web;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.persistence.EntityManager;

import de.unimuenster.pi.bicycle.jpa.Customer;

public class CustomerConverter implements Converter {

    private EntityManager em;
    
    public CustomerConverter(EntityManager em) {
	this.em = em;
    }
    
    @Override
    public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
	if(arg2 == null)
	    return null;
	try {
	    int id = Integer.parseInt(arg2);
	    return em.find(Customer.class, id);
	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    return null;
	}
    }

    @Override
    public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {
	if(arg2 != null && arg2 instanceof Customer)
	    return ((Customer) arg2).getId() +"";
	return null;
    }

}
