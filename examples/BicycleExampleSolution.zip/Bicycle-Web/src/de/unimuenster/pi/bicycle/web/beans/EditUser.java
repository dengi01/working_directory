package de.unimuenster.pi.bicycle.web.beans;

import java.io.Serializable;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import de.unimuenster.pi.bicycle.ejb.UserServiceBean;
import de.unimuenster.pi.bicycle.jpa.Customer;
import de.unimuenster.pi.bicycle.jpa.Employee;
import de.unimuenster.pi.bicycle.jpa.User;
import de.unimuenster.pi.bicycle.web.Util;

@ViewScoped
@ManagedBean(name = "editUser")
public class EditUser implements Serializable {
    private static final long serialVersionUID = 1L;

    @Inject
    Logger log;

    @ManagedProperty(value = "#{login}")
    Login loginBean;

    public void setLoginBean(Login loginBean) {
	this.loginBean = loginBean;
    }

    @EJB
    UserServiceBean userEjb;

    User user;
    int userid;

    public void setId(Integer id) {
	// customers are only allowed to edit there own user.
	if ((!loginBean.isLoggedIn() && id > 0)
		|| (loginBean.isCustomer() && loginBean.getCurrentUser().getId() != id)) {
	    log.info("User tried edit other user [id:" + id + "]");
	    FacesContext.getCurrentInstance().addMessage(null,
		    Util.infoMessage("You are not allowed to edit this user."));
	    Util.redirectToRoot();
	    return;
	}
	if (!loginBean.isLoggedIn()) {
	    user = new Customer();
	}
	if (loginBean.isCustomer()) {
	    user = userEjb.findUserById(loginBean.getCurrentUser().getId());
	} else if (loginBean.isEmployee()) {
	    if (id <= 0) {
		user = new Employee();
		id = 0;
	    } else
		user = userEjb.findUserById(id);
	    userid = id;
	}
	return;
    }

    public Integer getId() {
	return null;
    }

    public User getUser() {
	if (user == null && loginBean.isCustomer())
	    user = userEjb.findUserById(loginBean.getCurrentUser().getId());
	else if (user == null)
	    user = new Customer();
	return user;
    }

    public String persist() {
	try {
	    log.info("Persist called for " + user.toString() + user.getAdditionalInformation());
	    if (!loginBean.isLoggedIn() && getUser() instanceof Customer) {
		userEjb.createCustomer((Customer) getUser());
		FacesContext.getCurrentInstance().addMessage(null,
			Util.successMessage("The user has been created."));
		user = null;
	    } else if (loginBean.getCurrentUser().getId() == getUser().getId()) {
		userEjb.mergeUser(user);
		FacesContext.getCurrentInstance().addMessage(null,
			Util.successMessage("Changes are saved."));
	    } else if (loginBean.isEmployee()) {
		if(user.getId() != 0) {
		    userEjb.mergeUser(user);
		FacesContext.getCurrentInstance().addMessage(null,
			Util.successMessage("Changes are saved."));
		} else {
		    userEjb.createUser(user);
		    FacesContext.getCurrentInstance().addMessage(null,
				Util.successMessage("The user has been created."));
		}
	    }
	} catch (EJBException e) {
	    FacesContext.getCurrentInstance().addMessage(null,Util.errorMessage(Util.getConstraintMessage(e)));
	}
	return null;
    }
    
    public String deleteUser(int id) {
	User user = userEjb.findUserById(id);
	try {
	    if(user.getId() == loginBean.getCurrentUser().getId()) {
		userEjb.removeUser(user);
		return loginBean.logout();
	    } else if (loginBean.isEmployee()) {
		userEjb.removeUser(user);
		FacesContext.getCurrentInstance().addMessage(null, Util.successMessage("User deleted successfully."));
		setId(0);
	    } else 
		FacesContext.getCurrentInstance().addMessage(null, Util.successMessage("You are not allowed to remove this user."));
	} catch (EJBException e) {
	    FacesContext.getCurrentInstance().addMessage(null, Util.errorMessage(Util.getConstraintMessage(e)));
	}
	return null;
    }

    public String changeType() {
	User oldUser = user;
	if (getUser() instanceof Customer) {
	    user = new Employee();
	} else if (getUser() instanceof Employee) {
	    user = new Customer();
	}
	user.copyUser(oldUser);
	return "";
    }

    public boolean isNewUser() {
	return getUser().getId() == 0;
    }

    public Customer getCustomer() {
	if (user instanceof Customer) {
	    return (Customer) user;
	}
	return null;
    }

    public Employee getEmployee() {
	if (user instanceof Employee)
	    return (Employee) user;
	return null;
    }
}