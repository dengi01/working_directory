package de.unimuenster.pi.bicycle.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Remove;
import javax.enterprise.inject.Produces;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import de.unimuenster.pi.bicycle.ejb.UserServiceBean;
import de.unimuenster.pi.bicycle.jpa.Customer;
import de.unimuenster.pi.bicycle.jpa.Employee;
import de.unimuenster.pi.bicycle.jpa.User;
import de.unimuenster.pi.bicycle.web.Util;

@SessionScoped
@ManagedBean(name = "login")
public class Login implements Serializable {

    private static final long serialVersionUID = 1L;

    @Inject
    // Produced in Util.java
    Logger log;

    @EJB
    private UserServiceBean userEjb;

    private User currentUser;

    @Produces
    public User getCurrentUser() {
	return currentUser;
    }

    public boolean isLoggedIn() {
	return currentUser != null;
    }

    public boolean isCustomer() {
	return isLoggedIn() && currentUser instanceof Customer;
    }

    public boolean isEmployee() {
	return isLoggedIn() && currentUser instanceof Employee;
    }

    public String login() {
	log.info("User tries to log in: " + username + " " + password);
	currentUser = userEjb.login(username, password);
	password = username = "";
	if (currentUser != null) {
	    log.info("User logged in: " + currentUser);
	    FacesContext.getCurrentInstance().addMessage(null,
		    Util.successMessage("You logged in successfully!"));
	    return "success";
	} else {
	    FacesContext.getCurrentInstance().addMessage(null,
		    Util.warnMessage("Username or password wrong!"));
	    return "failed";
	}
    }

    @Remove
    public String logout() {
	FacesContext.getCurrentInstance().addMessage(null,
		Util.infoMessage("Goodbye, " + currentUser.getFullName()));
	currentUser = null;
	FacesContext facesContext = FacesContext.getCurrentInstance();
	  HttpSession httpSession = (HttpSession)facesContext.getExternalContext().getSession(false);
	  httpSession.invalidate();
	  Util.redirectToRoot();
	return "logout";
    }

    public void setPassword(String password) {
	this.password = password;
    }

    public void setUsername(String username) {
	this.username = username;
    }

    public boolean isDebug() {
	return true;
    }

    public Collection<User> getDebugUsers() {
	if (!isDebug())
	    return new ArrayList<User>();
	return userEjb.getUsers();
    }

    public int getDebugUser() {
	return currentUser != null ? currentUser.getId() : 0;
    }

    public void setDebugUser(int id) {
	if (isDebug()) {
	    User u = userEjb.findUserById(id);
	    username = u.getUsername();
	    password = u.getPassword();
	}
    }
    private String username;
    private String password;

    public String getPassword() {
	return "";
    }

    public String getUsername() {
	return username;
    }
    
}
