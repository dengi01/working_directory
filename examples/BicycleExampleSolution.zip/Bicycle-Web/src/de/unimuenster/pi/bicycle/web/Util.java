package de.unimuenster.pi.bicycle.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import javax.ejb.EJBException;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

public class Util {

	public static String getConstraintMessage(EJBException e) {
		String message = "";
		if (e.getCausedByException() instanceof ConstraintViolationException) {
			ConstraintViolationException cve = (ConstraintViolationException) e
					.getCausedByException();
			Set<ConstraintViolation<?>> violations = cve
					.getConstraintViolations();
			if (violations != null)
				for (ConstraintViolation<?> cur : violations)
					message += cur.getMessage() + " ";
			else
				message += cve.getMessage();
		} else
			message += e.getMessage();
		return message;
	}

	public static void redirectToRoot() {
		try {
			ExternalContext ctx = FacesContext.getCurrentInstance()
					.getExternalContext();
			ctx.redirect("/" + ctx.getContextName() + "/");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Expose a JDK logger for injection. In order to save a bit more boiler
	 * plate, the the class name is automatically set as logger category.
	 * 
	 */
	@Produces
	Logger getLogger(InjectionPoint ip) {
		String category = ip.getMember().getDeclaringClass().getName();
		return Logger.getLogger(category);
	}
	
	public static FacesMessage infoMessage(String text) {
		return new FacesMessage(FacesMessage.SEVERITY_INFO, text, text);
	}
	public static FacesMessage warnMessage(String text) {
		return new FacesMessage(FacesMessage.SEVERITY_WARN, text, text);
	}
	public static FacesMessage errorMessage(String text) {
		return new FacesMessage(FacesMessage.SEVERITY_ERROR, text, text);
	}
	public static FacesMessage successMessage(String text) {
		return new FacesMessage(FacesMessage.SEVERITY_FATAL, text, text);
	}
	
	/**
	 * Converts a Map to a List filled with its entries. This is needed since
	 * very few if any JSF iteration components are able to iterate over a map.
	 */
	public static <T, S> List<Map.Entry<T, S>> mapToList(Map<T, S> map) {

		if (map == null) {
			return null;
		}

		List<Map.Entry<T, S>> list = new ArrayList<Map.Entry<T, S>>();
		list.addAll(map.entrySet());

		return list;
	}
	public static <K,V> List<Map.Entry<K, V>> idMapToList(Map<Integer,? extends Map.Entry<K,V>> map) {
	    if (map == null) {
		return new LinkedList<Map.Entry<K,V>>();
	}
	    List<Map.Entry<K,V>> list = new ArrayList<Map.Entry<K,V>>();
	    list.addAll(map.values());
	    
	    return list;
	}
}
