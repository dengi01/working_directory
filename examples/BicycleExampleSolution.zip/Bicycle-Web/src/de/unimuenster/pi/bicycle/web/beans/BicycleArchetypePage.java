package de.unimuenster.pi.bicycle.web.beans;

import java.util.Collection;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import de.unimuenster.pi.bicycle.ejb.BicycleArchetypeServiceBean;
import de.unimuenster.pi.bicycle.ejb.BicycleServiceBean;
import de.unimuenster.pi.bicycle.ejb.ReservationServiceBean;
import de.unimuenster.pi.bicycle.jpa.Bicycle;
import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;
import de.unimuenster.pi.bicycle.jpa.Reservation;
import de.unimuenster.pi.bicycle.web.Util;

@ManagedBean(name="bicycleArchetypePage")
@ViewScoped
public class BicycleArchetypePage {
	
	@EJB
	private BicycleArchetypeServiceBean archetypeEjb;
	@EJB
	private BicycleServiceBean bikeEjb;
	@EJB
	private ReservationServiceBean reservationEjb;
	private int archetypeID;
	private BicycleArchetype archetype;
	private Bicycle newBicycle;

	public void ensureInitialized() {
		try{
			if(getArchetype() != null)
				// Success
				return;
		} catch(EJBException e) {
			e.printStackTrace();
		}
		Util.redirectToRoot();
	}
	
	public int getArchetypeID() {
		return archetypeID;
	}
	
	public void setArchetypeID(int archetypeID) {
		this.archetypeID = archetypeID;
		this.archetype = null;
	}

	public BicycleArchetype getArchetype() {
		if (archetype == null)
			archetype = archetypeEjb.getBicycleArchetype(getArchetypeID());
		return archetype;
	}

	public void setArchetype(BicycleArchetype archetype) {
		this.archetype = archetype;
	}
	
	public Collection<Bicycle> getBicycles() {
		return bikeEjb.getBicycleOfArchetype(archetype);
	}
	
	public Collection<Reservation> getReservationForBicycle(Bicycle bike) {
		return reservationEjb.getReservationsForBicycle(bike);
	}
	
	public Bicycle getNewBicycle() {
		if(newBicycle == null) {
			newBicycle=new Bicycle();
			newBicycle.setArchetype(archetype);
		}
		return newBicycle;
	}
	
	public void setNewBicycle(Bicycle newBicycle) {
		this.newBicycle = newBicycle;
	}
	
	public void addBicycle() {
		try{
			bikeEjb.createBicycle(newBicycle);
			newBicycle = null;
		}catch (EJBException e) {
			FacesContext.getCurrentInstance().addMessage("bicycleForm:serialNumber", Util.errorMessage("Serial number is already used. " + Util.getConstraintMessage(e)));
			e.printStackTrace();
			//ID is generated before Exception is raised --> detached entity exception is raised after second save
			newBicycle.setId(0);
		}		
	}
}