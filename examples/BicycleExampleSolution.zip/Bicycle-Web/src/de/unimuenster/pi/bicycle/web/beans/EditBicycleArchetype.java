package de.unimuenster.pi.bicycle.web.beans;

import java.io.Serializable;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.bicycle.ejb.BicycleArchetypeServiceBean;
import de.unimuenster.pi.bicycle.jpa.BicycleArchetype;
import de.unimuenster.pi.bicycle.web.SearchArtefactConverter;
import de.unimuenster.pi.bicycle.web.Util;

/**
 * Backing bean for the create book page.
 */
@ViewScoped
@ManagedBean(name = "editArchetype")
public class EditBicycleArchetype implements Serializable {
	private static final long serialVersionUID = 1L;
	private BicycleArchetype archetype;

	@PersistenceContext
	EntityManager em;

	@EJB
	private BicycleArchetypeServiceBean archetypeService;

	private int id;
	
	public String saveExisting() {
		try{
			archetypeService.mergeBicycleArchetype(archetype);
			FacesContext.getCurrentInstance().addMessage(
					null,
					Util.successMessage(archetype.getName()
							+ " saved successfully."));
			archetype = null;
		} catch (EJBException e) {
			FacesContext.getCurrentInstance().addMessage(
					null,
					Util.errorMessage("Bicycle archetype not saved: "
							+ Util.getConstraintMessage(e)));
		}
		return null;
	}
	
	public String persist() {
		// Action
		try {
			archetypeService.createBicycleArchetype(archetype);
			FacesContext.getCurrentInstance().addMessage(
					null,
					Util.successMessage(archetype.getName()
							+ " created successfully."));
			archetype = null;
			id = 0;
		} catch (EJBException e) {
			FacesContext.getCurrentInstance().addMessage(
					null,
					Util.errorMessage("Bicycle archetype not created: "
							+ Util.getConstraintMessage(e)));
		}
		return null;
	}

	public BicycleArchetype getArchetype() {
		if (archetype == null)
			archetype = new BicycleArchetype();
		return archetype;
	}

	public void setArchetype(BicycleArchetype archetype) {
		this.archetype = archetype;
	}

	public Converter getSearchArtefactConverter() {
		return new SearchArtefactConverter(em);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
		if(id <= 0)
			archetype = new BicycleArchetype();
		else
			try {
				archetype = archetypeService.getBicycleArchetype(id);
				
			} catch (EJBException e) {
				FacesContext.getCurrentInstance().addMessage(null, Util.errorMessage(Util.getConstraintMessage(e)));
				archetype = new BicycleArchetype();
			}
	} 
}
