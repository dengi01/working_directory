Bicycle Application (Java EE 7)

Technologies:
* JPA 2.0
* Bean Validation (JSR 303)
* EJB 3.1
* JSF 2.0
* (JAX-WS, Servlet 3.0)

Author:
* Claus Alexander Usener

Last update: 2012-04-16

Requirements:
* JBoss AS 7.1
* Eclipse 3.7 + JBoss Tools 3.7
* see http://www.wi.uni-muenster.de/pi/lehre/ss12/EAI/tutorials/tutorial_jboss_project.html#precond

Instructions (from http://www.wi.uni-muenster.de/pi/lehre/ss12/EAI/tutorials/tutorial_jboss_project.html#import)
* Select "File->Import..." from the Eclipse menu bar.
* Choose "General > Existing Projects into Workspace" and click next.
* Choose "Select archive file" and browse to this archive.
* Four projects called Bicycle, Bicycle-EJB, Bicycle-Persistence and Bicycle-Web should appear under "Projects". Make sure all four are selected and "Finish".
* The project explorer should now contain the four projects. Eclipse will automatically validate and build the projects.
* In the "Servers" tab, right-click on your JBoss 7.1 server and select "Add and Remove...".
* Select the Bicycle application and click "Add >", then "Finish.
* Start the server and wait until the application has been deployed.
* The Bicycle web application is accessible under http://localhost:8080/Bicycle-Web/.

* Please make sure, that you provide the right Data Source: java:/Bicycle00