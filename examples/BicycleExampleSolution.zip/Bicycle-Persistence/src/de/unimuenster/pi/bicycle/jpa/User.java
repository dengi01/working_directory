package de.unimuenster.pi.bicycle.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;

/**
 * Entity implementation class for Entity: User
 * 
 */
//@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@Entity
public class User implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id = 0; //0 --> User is not part of Persistence Context.
	@Column(unique = true)
	@Size(min = 5, message = "Username too short (at least 6 characters required)")
	private String username;
	@Size(min = 5, message = "Password too short (at least 6 characters required)")
	private String password;
	@Size(min = 2)
	private String firstname;
	@Size(min = 2)
	private String lastname;

	public User() {
		super();
	}

	public User(String username, String password, String firstname,
			String lastname) {
		super();
		this.setUsername(username);
		this.setPassword(password);
		this.setLastname(lastname);
		this.setFirstname(firstname);
	}

	public String getFirstname() {
		return this.firstname;
	}

	public int getId() {
		return this.id;
	}

	public String getLastname() {
		return this.lastname;
	}

	public String getPassword() {
		return this.password;
	}

	public String getUsername() {
		return this.username;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getFullName() {
		return getFirstname() + " " + getLastname();
	}
	public String getType() {
		return this.getClass().getSimpleName();
	}
	public String getAdditionalInformation() {
		return "";
	}
	
	public String toString() {
		return getUsername()+" (id:"+getId()+"): " + getFullName();
	}
	
	public void copyUser(User toCopy) {
		this.setFirstname(toCopy.getFirstname());
		this.setLastname(toCopy.getLastname());
		this.setUsername(toCopy.getUsername());
		this.setPassword(toCopy.getPassword());
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj instanceof User) {
		    User user = (User) obj;
		    return user.getId() == this.getId() && user.getUsername().equals(this.getUsername());
		}
		return false;
	}
}
