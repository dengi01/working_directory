package de.unimuenster.pi.bicycle.jpa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * Entity implementation class for Entity: Customer
 * 
 */
@Entity
public class Customer extends User implements Serializable {

	protected static final long serialVersionUID = 1L;
	
	@NotNull
	private String street;
	@NotNull
	private String city;
	@Pattern(regexp = "[0-9]*", message = "Zipcode - illegal character (only digits allowed)")
	@Size(max = 5)
	private String zipcode;
	
	@OneToMany(cascade=CascadeType.REMOVE,mappedBy="customer")
	Collection<Reservation> reservations = new ArrayList<Reservation>();

	public Customer() {
		super();
	}
	public Customer(String username,String password, String firstname,String lastname,String street,String city,String zipcode) {
		super(username, password, firstname, lastname);
		this.setCity(city);
		this.setStreet(street);
		this.setZipcode(zipcode);
	}

	public String getCity() {
		return this.city;
	}

	public String getStreet() {
		return this.street;
	}

	public String getZipcode() {
		return this.zipcode;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
	public void setReservations(Collection<Reservation> reservations) {
		this.reservations = reservations;
	}
	public Collection<Reservation> getReservations() {
		return reservations;
	}
	public void addReservation(Reservation reservation) {
		reservations.add(reservation);
		reservation.setCustomer(this);
	}
	public String toString() {
		return "[CUSTOMER] " + super.toString();
	}
	
	public String getAdditionalInformation() {
		return "Address: " + getStreet() + "; " + getZipcode() + " " + getCity();
	}
}
