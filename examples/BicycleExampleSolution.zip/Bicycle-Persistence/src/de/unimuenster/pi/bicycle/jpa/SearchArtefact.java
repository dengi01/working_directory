package de.unimuenster.pi.bicycle.jpa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.validator.constraints.NotBlank;

/**
 * Entity implementation class for Entity: SearchType
 * 
 */
@Entity
public class SearchArtefact implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@NotBlank
	private String name;
	@Enumerated(EnumType.STRING)
	private SearchCategory category;
	
	@OneToMany
	private Collection<BicycleArchetype> bicycleArchetypes = new ArrayList<BicycleArchetype>();

	protected static final long serialVersionUID = 1L;

	public SearchArtefact() {
		super();
	}

	public SearchArtefact(String name, SearchCategory category) {
		super();
		this.name = name;
		this.category = category;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (obj instanceof SearchArtefact)
			return ((SearchArtefact) obj).getId() == this.getId();
		return false;
	}

	public SearchCategory getCategory() {
		return this.category;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public void setCategory(SearchCategory category) {
		this.category = category;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Collection<BicycleArchetype> getBicycleArchetypes() {
		return bicycleArchetypes;
	}

	public void setBicycleArchetypes(Collection<BicycleArchetype> bicycleArchetypes) {
		this.bicycleArchetypes = bicycleArchetypes;
	}
}
