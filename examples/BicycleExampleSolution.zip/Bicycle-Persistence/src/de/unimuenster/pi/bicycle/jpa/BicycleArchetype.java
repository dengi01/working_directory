package de.unimuenster.pi.bicycle.jpa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

/**
 * Entity implementation class for Entity: BicycleArchetype
 * 
 */
@Entity
public class BicycleArchetype implements Serializable {

	protected static final long serialVersionUID = 1L;
	@ManyToOne
	private SearchArtefact bicycleCategory;
	@OneToMany(mappedBy = "archetype")
	private Collection<Bicycle> bicycles = new ArrayList<Bicycle>();

	private String description;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Size(min=4,message="must be longer than 3 characters")
	private String name;
	@Min(value = 0)
	private int price = 0;
	@ManyToOne
	private SearchArtefact size;

	@ManyToOne
	private SearchArtefact transmission;

	public BicycleArchetype() {
		super();
	}

	public SearchArtefact getBicycleCategory() {
		return this.bicycleCategory;
	}

	public Collection<Bicycle> getBicycles() {
		return this.bicycles;
	}

	public String getDescription() {
		return this.description;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public int getPrice() {
	    return price;
	}

	public SearchArtefact getSize() {
		return this.size;
	}

	public SearchArtefact getTransmission() {
		return this.transmission;
	}

	public void setBicycleCategory(SearchArtefact bicycleCategory) {
		this.bicycleCategory = bicycleCategory;
	}

	public void setBicycles(Collection<Bicycle> bicycles) {
		this.bicycles = bicycles;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPrice(int price) {
	    this.price = price;
	}

	public void setSize(SearchArtefact size) {
		this.size = size;
	}

	public void setTransmission(SearchArtefact transmission) {
		this.transmission = transmission;
	}

}
