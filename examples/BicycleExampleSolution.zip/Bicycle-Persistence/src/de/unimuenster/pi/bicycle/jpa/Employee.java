package de.unimuenster.pi.bicycle.jpa;

import java.io.Serializable;

import javax.persistence.Entity;

/**
 * Entity implementation class for Entity: Employee
 * 
 */
@Entity
public class Employee extends User implements Serializable {

	/**
	 * 
	 */
	protected static final long serialVersionUID = 1L;
	private int employeeNo;

	public Employee() {
		super();
	}

	public Employee(String username, String password, String firstname,
			String lastname) {
		super(username, password, firstname, lastname);
	}

	public int getEmployeeNo() {
		return this.employeeNo;
	}

	public void setEmployeeNo(int employeeNo) {
		this.employeeNo = employeeNo;
	}
	
	public String toString() {
		return "[EMPLOYEE] " + super.toString();
	}
	
	public String getAdditionalInformation() {
		return "Employee No.: " + getEmployeeNo();
	}
}
