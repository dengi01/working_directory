package de.unimuenster.pi.bicycle.jpa;

public enum SearchCategory {
	SIZE("Size"), TRANSMISSION("Transmission"), BICYCLE_CATEGORY(
			"Bicycle Category");

	String name;

	private SearchCategory(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	@Override
	public String toString() {
		return this.name;
	}
}
