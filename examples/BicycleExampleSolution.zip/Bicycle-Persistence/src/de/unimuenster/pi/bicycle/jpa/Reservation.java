package de.unimuenster.pi.bicycle.jpa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.management.timer.Timer;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 * Entity implementation class for Entity: Reservation
 * 
 */
@Entity
public class Reservation implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @ManyToOne
    private Customer customer;
    
    @ManyToMany(fetch=FetchType.EAGER)
    private Collection<Bicycle> bicycles = new ArrayList<Bicycle>();

    @NotNull
    @Temporal(TemporalType.TIMESTAMP)
    private Date firstDay;
    @NotNull
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastDay;
 
    private Date payDay = null;
    protected static final long serialVersionUID = 1L;

    public Reservation() {
	super();
    }

    public Reservation(Customer customer, Date firstDay, Date lastDay) {
	super();
	this.setCustomer(customer);
	this.setFirstDay(firstDay);
	this.setLastDay(lastDay);
    }

    public void addBicycle(Bicycle bike) {
	this.bicycles.add(bike);
	bike.addReservation(this);
    }

    public void addBicycles(Collection<Bicycle> bicycles) {
	for (Bicycle bike : bicycles) {
	    this.addBicycle(bike);
	}
    }

    public Collection<Bicycle> getBicycles() {
	return this.bicycles;
    }

    public Customer getCustomer() {
	return this.customer;
    }

    public Date getFirstDay() {
	return firstDay;
    }

    public int getId() {
	return this.id;
    }

    public Date getLastDay() {
	if (lastDay != null)
	    return new Date(lastDay.getTime()- 20L * Timer.ONE_HOUR);
	return lastDay;
    }

    public boolean isPaid() {
	return payDay != null;
    }

    public void setPayDay(Date payDay) {
	this.payDay = payDay;
    }

    public Date getPayDay() {
	return payDay;
    }

    public void removeBicycle(Bicycle bike) {
	this.bicycles.remove(bike);
	bike.removeReservation(this);
    }

    public void setBicycles(Collection<Bicycle> bicycles) {
	this.bicycles = bicycles;
    }
    public Map<Integer,Integer> getArchetypeCountBicycles() {
	HashMap<Integer, Integer> result = new HashMap<Integer, Integer>();
	for(Bicycle bike : bicycles) {
	    Integer count = result.get(bike.getArchetype().getId());
	    count = count == null ? 0+1 : count+1;
	    result.put(bike.getArchetype().getId(), count);
	}
	return result;
    }
     
    public void setCustomer(Customer customer) {
	this.customer = customer;
    }

    public void setFirstDay(Date firstDay) {
	if (firstDay !=null && lastDay != null && firstDay.after(lastDay))
	    lastDay = firstDay;
	this.firstDay = firstDay;
	
    }

    public void setId(int id) {
	this.id = id;
    }

    public void setLastDay(Date lastDay) {
	if (lastDay != null && firstDay != null && firstDay.after(lastDay))
	    lastDay = firstDay;
	if(lastDay != null) {
	    //Booking time is till the end of the day.
	    this.lastDay = new Date(lastDay.getTime()+ 20L * Timer.ONE_HOUR);
	} else {
	    this.lastDay = null;	    
	}
    }

    public String toString() {
	return "[Reservation]: " + firstDay + " - " + lastDay + " " + bicycles.size();
    }
    
    public long getCountDays() {
	if (firstDay == null || lastDay == null)
	    return 0;
	return (lastDay.getTime() - firstDay.getTime())/ Timer.ONE_DAY + 1;
    }
    
    public void updateReservationWithValues(Reservation res) {
	this.customer = res.customer;
	this.firstDay = res.firstDay;
	this.lastDay = res.lastDay;
	this.payDay = res.payDay;
    }
}
