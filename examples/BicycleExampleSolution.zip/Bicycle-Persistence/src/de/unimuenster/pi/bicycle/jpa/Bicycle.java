package de.unimuenster.pi.bicycle.jpa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Entity implementation class for Entity: Bicycle
 * 
 */
@Entity
//@Table(name="Bicycle", uniqueConstraints=@UniqueConstraint(columnNames={"serialNumber"}))
public class Bicycle implements Serializable {

	protected static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@ManyToOne(fetch=FetchType.EAGER)
	private BicycleArchetype archetype;

	@Column(unique=true)
	@NotNull
	@Size(min=5,max= 15,message="Length musst be between 5 and 15 characters.")
	private String serialNumber;
	@ManyToMany(mappedBy = "bicycles")
	private Collection<Reservation> reservations = new ArrayList<Reservation>();

	public Bicycle() {
		super();
	}

	public void addReservation(Reservation reservation) {
		this.reservations.add(reservation);
	}

	public BicycleArchetype getArchetype() {
		return this.archetype;
	}

	public int getId() {
		return this.id;
	}

	public Collection<Reservation> getReservations() {
		return this.reservations;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void removeReservation(Reservation reservation) {
		this.reservations.remove(reservation);
	}

	public void setArchetype(BicycleArchetype archetype) {
		this.archetype = archetype;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setReservations(Collection<Reservation> reservation) {
		this.reservations = reservation;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
}
