package de.unimuenster.pi.laundry.ejb;

import java.util.Collection;

import javax.ejb.Remote;

import de.unimuenster.pi.laundry.jpa.Owner;
import de.unimuenster.pi.laundry.jpa.Textile;

/**
 * Service class for management of owner objects.
 * @author Henning Heitkoetter
 */
@Remote
public interface OwnerService {
	Owner createOwner(String name, int customerId, String addressSupplement);
	
	Owner createOwner(Owner newOwner, int customerId);
	
	Owner updateAddressSupplement(int ownerId, String newAddressSupplement);
	
	void removeOwner(int ownerId);

	Owner getOwner(int ownerId);
	
	Collection<Textile> getTextilesOfOwner(int ownerId);
}
