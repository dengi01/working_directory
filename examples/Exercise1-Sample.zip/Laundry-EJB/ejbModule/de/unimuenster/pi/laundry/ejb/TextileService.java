package de.unimuenster.pi.laundry.ejb;
import javax.ejb.Remote;

import de.unimuenster.pi.laundry.jpa.Textile;
import de.unimuenster.pi.laundry.jpa.WashingProgram;

/**
 * Service class for management of textiles.
 * @author Henning Heitkoetter
 */
@Remote
public interface TextileService {
	Textile createTextile(String barcode, int ownerId, String description, WashingProgram defaultProgram);
	
	Textile createTextile(Textile newTextile, int ownerId);
	
	Textile updateTextile(Textile changedTextile);
	
	Textile getTextile(String barcode);

	Textile getTextile(int textileId);
}
