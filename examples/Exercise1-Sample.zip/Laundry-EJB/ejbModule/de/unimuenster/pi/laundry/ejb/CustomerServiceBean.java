package de.unimuenster.pi.laundry.ejb;

import java.util.Collection;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.ConstraintViolationException;

import de.unimuenster.pi.laundry.jpa.CleaningOrder;
import de.unimuenster.pi.laundry.jpa.Customer;
import de.unimuenster.pi.laundry.jpa.Owner;

/**
 * Session Bean implementation class CustomerServiceBean
 * @author Henning Heitkoetter
 */
@Stateless
public class CustomerServiceBean implements CustomerService {
	@PersistenceContext
	private EntityManager em;

	@Override
	public Customer createCustomer(String name, String address) {
		Customer newCustomer = new Customer();
		newCustomer.setName(name);
		newCustomer.setAddress(address);
		return createCustomer(newCustomer);
	}

	@Override
	public Customer createCustomer(Customer newCustomer) {
		if(em.createQuery("SELECT COUNT(*) FROM Customer WHERE Name=:name", Long.class).setParameter("name", newCustomer.getName())
				.getSingleResult() > 0)
			throw new ConstraintViolationException(String.format("Customer with name '%s' already in database" , newCustomer.getName()), null);
		
		em.persist(newCustomer);
		return newCustomer;
	}

	@Override
	public Customer updateAddress(int customerId, String newAddress) {
		Customer cust = getCustomer(customerId);
		
		cust.setAddress(newAddress);
		return cust;
	}

	@Override
	public Customer getCustomer(int customerId) {
		Customer cust = em.find(Customer.class, customerId);
		if(cust == null)
			throw new IllegalArgumentException(String.format("Customer with ID %s not found", customerId));
		return cust;
	}

	@Override
	public Collection<Customer> getAllCustomers() {
		return em.createQuery("FROM Customer", Customer.class).getResultList();
	}
	
	@Override
	public Collection<Owner> getOwnersOfCustomer(int customerId) {
		Customer customer = getCustomer(customerId);
		Collection<Owner> owners = customer.getOwners();
		// Initialize
		owners.size();
		return owners;
	}
	
	@Override
	public Collection<CleaningOrder> getOrdersOfCustomer(int customerId) {
		Customer customer = getCustomer(customerId);
		Collection<CleaningOrder> orders = customer.getOrders();
		// Initialize
		orders.size();
		return orders;
	}
}
