package de.unimuenster.pi.laundry.ejb;

import java.util.List;

import javax.ejb.Remote;

import de.unimuenster.pi.laundry.jpa.Customer;
import de.unimuenster.pi.laundry.jpa.Owner;
import de.unimuenster.pi.laundry.jpa.Textile;

/**
 * Service class for searching the database.
 * All queries are case-insensitive and return all objects whose search key contains the search string.
 * An empty search string is allowed and will return all object of the respective type.
 * @author Henning Heitkoetter
 */
@Remote
public interface SearchService {
	List<Customer> searchForCustomer(String searchString);
	
	List<Owner>  searchForOwner(String searchString);
	
	List<Textile>  searchForTextile(String searchString);
}
