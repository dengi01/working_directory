package de.unimuenster.pi.laundry.ejb;

import static de.unimuenster.pi.laundry.jpa.CleaningOrder.State.Processing;
import static de.unimuenster.pi.laundry.jpa.CleaningOrder.State.Delivered;
import static de.unimuenster.pi.laundry.jpa.CleaningOrder.State.Finished;
import static de.unimuenster.pi.laundry.jpa.CleaningOrder.State.Invoiced;
import static de.unimuenster.pi.laundry.jpa.CleaningOrder.State.Paid;
import static de.unimuenster.pi.laundry.jpa.CleaningOrderPosition.State.Received;
import static de.unimuenster.pi.laundry.jpa.CleaningOrderPosition.State.Cleaning;
import static de.unimuenster.pi.laundry.jpa.CleaningOrderPosition.State.Cleaned;

import java.util.Collection;
import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.laundry.jpa.CleaningOrder;
import de.unimuenster.pi.laundry.jpa.CleaningOrderPosition;
import de.unimuenster.pi.laundry.jpa.Customer;
import de.unimuenster.pi.laundry.jpa.Textile;
import de.unimuenster.pi.laundry.jpa.WashingProgram;

/**
 * Session Bean implementation class CleaningOrderServiceBean
 * @author Henning Heitkoetter
 */
@Stateless
public class CleaningOrderServiceBean implements CleaningOrderService {
	@PersistenceContext
	private EntityManager em;
	@EJB
	private CustomerService cs;
	@EJB
	private TextileService ts;

	@Override
	public CleaningOrder createCleaningOrder(int customerId, Date dateOfReceipt) {
		Customer customer = em.merge(cs.getCustomer(customerId));

		if(dateOfReceipt == null)
			dateOfReceipt = new Date();
		
		CleaningOrder newOrder = new CleaningOrder();
		newOrder.setCustomer(customer);
		newOrder.setDateOfReceipt(dateOfReceipt);
		em.persist(newOrder);
		return newOrder;
	}

	@Override
	public CleaningOrder setDelivered(int cleaningOrderId) {
		CleaningOrder order = getOrderAndEnsureState(cleaningOrderId, Finished);
		
		order.setState(Delivered);
		for(CleaningOrderPosition cur : order.getPositions())
			cur.getTextile().setCurrentOrder(null);
		return order;
	}

	@Override
	public CleaningOrder setInvoiced(int cleaningOrderId, int invoiceAmount) {
		CleaningOrder order = getOrderAndEnsureState(cleaningOrderId, Delivered);
		
		order.setState(Invoiced);
		order.setInvoiceAmount(invoiceAmount);
		return order;
	}

	@Override
	public CleaningOrder setPaid(int cleaningOrderId) {
		CleaningOrder order = getOrderAndEnsureState(cleaningOrderId, Invoiced);
		
		order.setState(Paid);
		return order;
	}

	private CleaningOrder getOrderAndEnsureState(int cleaningOrderId, CleaningOrder.State expectedState) {
		CleaningOrder order = getCleaningOrder(cleaningOrderId);
		if(order.getState() != expectedState)
			throw new IllegalStateException(String.format("Cleaning order with ID %s is not in state '%s'", cleaningOrderId, expectedState));
		return order;
	}

	@Override
	public CleaningOrder getCleaningOrder(int cleaningOrderId) {
		CleaningOrder order = em.find(CleaningOrder.class, cleaningOrderId);
		if(order == null)
			throw new IllegalArgumentException(String.format("Cleaning order with ID %s not found", cleaningOrderId));
		return order;
	}

	@Override
	public CleaningOrderPosition createPosition(int cleaningOrderId,
			String barcode, WashingProgram programToUse) {
		Textile textile = em.merge(ts.getTextile(barcode));
		if(textile.getCurrentOrder() != null)
			throw new IllegalArgumentException(String.format("Textile with barcode '%s' already in (non-delivered) order %s", barcode, 
					textile.getCurrentOrder().getOrder().getId()));
		
		if(textile.getOwner() == null)
			throw new IllegalArgumentException(String.format("Textile with barcode '%s' not associated with any owner/customer", barcode));
		
		CleaningOrder order = getCleaningOrder(cleaningOrderId);
		if(order.getState() != Processing)
			throw new IllegalStateException(String.format(
					"Cleaning order #%s is already finished (state: %s)", order.getId(), order.getState()));
		if(!order.getCustomer().equals(textile.getOwner().getCustomer()))
			throw new IllegalArgumentException(String.format(
					"Customer of order and customer associated with textile do not match: order => %s, textile => %s", 
					order.getCustomer().getName(), textile.getOwner().getCustomer().getName()));
		
		if(programToUse == null)
			programToUse = textile.getDefaultProgram();
		
		CleaningOrderPosition newPosition = new CleaningOrderPosition();
		newPosition.setOrder(order);
		newPosition.setTextile(textile);
		textile.setCurrentOrder(newPosition);
		newPosition.setProgramToUse(programToUse);
		em.persist(newPosition);
		return newPosition;
	}

	@Override
	public CleaningOrderPosition setCleaning(String barcode) {
		Textile textile = em.merge(ts.getTextile(barcode));
		ensurePositionState(textile, Received);
		
		CleaningOrderPosition position = textile.getCurrentOrder();
		position.setState(Cleaning);
		return position;
	}

	@Override
	public CleaningOrderPosition setCleaned(String barcode) {
		Textile textile = em.merge(ts.getTextile(barcode));
		ensurePositionState(textile, Cleaning);
		
		CleaningOrderPosition position = textile.getCurrentOrder();
		position.setState(Cleaned);

		checkOrderFinished(position.getOrder());
		
		return position;
	}

	/**
	 * Checks if all positions of the given order are cleaned. If that is the case, set the state of the order to finished.
	 * @param order The order to check.
	 * @return <code>true</code>, if the order is finished.
	 */
	private boolean checkOrderFinished(CleaningOrder order) {
		boolean allPositionsFinished = true;
		for(CleaningOrderPosition cur : order.getPositions())
			if(cur.getState() != Cleaned){
				allPositionsFinished = false;
				break;
			}
		
		if(allPositionsFinished)
			order.setState(Finished);
		
		return allPositionsFinished;
	}

	/**
	 * Checks if the {@link Textile#getCurrentOrder() current order position} of <code>textile</code> is set and in state 
	 * <code>expected</code>.
	 * @param textile The textile whose current order position should be checked.
	 * @param expected The expected state of the order position.
	 * @throws IllegalArgumentException If one of the conditions outlined above is not met.
	 */
	private void ensurePositionState(Textile textile, CleaningOrderPosition.State expected) {
		CleaningOrderPosition position = textile.getCurrentOrder();
		if(position == null)
			throw new IllegalArgumentException(String.format("No current order for textile with barcode '%s'", textile.getBarcode()));
		if(position.getState() != expected)
			throw new IllegalArgumentException(String.format(
					"Current order position for textile with barcode '%s' is not in state '%s'", textile.getBarcode(), expected));
	}
	
	@Override
	public Collection<CleaningOrderPosition> getPositionsOfOrder(int orderId) {
		CleaningOrder order = getCleaningOrder(orderId);
		Collection<CleaningOrderPosition> positions = order.getPositions();
		// Initialize
		positions.size();
		return positions;
	}
}
