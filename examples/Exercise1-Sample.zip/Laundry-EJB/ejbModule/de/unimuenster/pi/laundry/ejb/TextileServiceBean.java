package de.unimuenster.pi.laundry.ejb;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.ConstraintViolationException;

import de.unimuenster.pi.laundry.jpa.Owner;
import de.unimuenster.pi.laundry.jpa.Textile;
import de.unimuenster.pi.laundry.jpa.WashingProgram;

/**
 * Session Bean implementation class TextileServiceBean
 * @author Henning Heitkoetter
 */
@Stateless
public class TextileServiceBean implements TextileService {
	@PersistenceContext
	private EntityManager em;
	@EJB
	private OwnerService os;
	
	@Override
	public Textile createTextile(String barcode, int ownerId,
			String description, WashingProgram defaultProgram) {
		Textile newTextile = new Textile();
		newTextile.setBarcode(barcode);
		newTextile.setDescription(description);
		if(defaultProgram != null)
			newTextile.setDefaultProgram(defaultProgram);
		return createTextile(newTextile, ownerId);
	}

	@Override
	public Textile createTextile(Textile newTextile, int ownerId) {
		Owner owner = em.merge(os.getOwner(ownerId));
		
		checkBarcodeUnique(newTextile);

		newTextile.setOwner(owner);
		em.persist(newTextile);
		return newTextile;
	}

	public void checkBarcodeUnique(Textile textile) {
		if(em.createQuery("SELECT COUNT(*) FROM Textile WHERE Barcode=:code", Long.class).setParameter("code", textile.getBarcode())
				.getSingleResult() > 0)
			throw new ConstraintViolationException(String.format("Barcode '%s' already in use" , textile.getBarcode()), null);
	}

	@Override
	public Textile updateTextile(Textile changedTextile) {
		Textile original = em.find(Textile.class, changedTextile.getId());
		
		if(!original.getBarcode().equals(changedTextile.getBarcode()))
			checkBarcodeUnique(changedTextile);
		
		return em.merge(changedTextile);
	}

	@Override
	public Textile getTextile(String barcode) {
		return em.createQuery("SELECT t FROM Textile t WHERE barcode=:code", Textile.class).setParameter("code", barcode).getSingleResult();
	}

	@Override
	public Textile getTextile(int textileId) {
		Textile textile = em.find(Textile.class, textileId);
		if(textile == null)
			throw new IllegalArgumentException(String.format("Textile with ID %s not found", textileId));
		return textile;
	}
}
