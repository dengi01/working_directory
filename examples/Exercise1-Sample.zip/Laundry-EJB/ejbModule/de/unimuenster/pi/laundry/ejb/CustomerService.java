package de.unimuenster.pi.laundry.ejb;
import java.util.Collection;

import javax.ejb.Remote;

import de.unimuenster.pi.laundry.jpa.CleaningOrder;
import de.unimuenster.pi.laundry.jpa.Customer;
import de.unimuenster.pi.laundry.jpa.Owner;

/**
 * Service class for the management of customer objects.
 * @author Henning Heitkoetter
 */
@Remote
public interface CustomerService {
	Customer createCustomer(String name, String address);
	
	Customer createCustomer(Customer newCustomer);
	
	Customer updateAddress(int customerId, String newAddress);

	Customer getCustomer(int customerId);
	
	Collection<Customer> getAllCustomers();

	Collection<Owner> getOwnersOfCustomer(int customerId);

	Collection<CleaningOrder> getOrdersOfCustomer(int customerId);
}
