package de.unimuenster.pi.laundry.ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.laundry.jpa.Customer;
import de.unimuenster.pi.laundry.jpa.Owner;
import de.unimuenster.pi.laundry.jpa.Textile;

/**
 * Session Bean implementation class SearchServiceBean
 * @author Henning Heitkoetter
 */
@Stateless
public class SearchServiceBean implements SearchService {
	@PersistenceContext
	private EntityManager em;

	@Override
	public List<Customer> searchForCustomer(String searchString) {
		if(searchString == null)
			searchString = "";
		
		return em.createQuery("FROM Customer WHERE UPPER(Name) LIKE :search", Customer.class)
			.setParameter("search", "%"+searchString.toUpperCase()+"%").getResultList();
	}

	@Override
	public List<Owner> searchForOwner(String searchString) {
		if(searchString == null)
			searchString = "";

		return em.createQuery("FROM Owner WHERE UPPER(Name) LIKE :search", Owner.class)
			.setParameter("search", "%"+searchString.toUpperCase()+"%").getResultList();
	}

	@Override
	public List<Textile> searchForTextile(String searchString) {
		if(searchString == null)
			searchString = "";
		
		return em.createQuery("FROM Textile WHERE UPPER(Barcode) LIKE :search", Textile.class)
			.setParameter("search", "%"+searchString.toUpperCase()+"%").getResultList();
	}

}
