package de.unimuenster.pi.laundry.ejb;

import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import de.unimuenster.pi.laundry.jpa.Customer;
import de.unimuenster.pi.laundry.jpa.Owner;
import de.unimuenster.pi.laundry.jpa.Textile;

/**
 * Session Bean implementation class OwnerServiceBean
 * @author Henning Heitkoetter
 */
@Stateless
public class OwnerServiceBean implements OwnerService {
	@PersistenceContext
	private EntityManager em;
	@EJB
	private CustomerService cs;

	@Override
	public Owner createOwner(String name, int customerId,
			String addressSupplement) {
		Owner newOwner = new Owner();
		newOwner.setName(name);
		newOwner.setAddressSupplement(addressSupplement);
		return createOwner(newOwner, customerId);
	}

	@Override
	public Owner createOwner(Owner newOwner, int customerId) {
		Customer customer = em.merge(cs.getCustomer(customerId));
		
		newOwner.setCustomer(customer);
		em.persist(newOwner);
		return newOwner;
	}

	@Override
	public Owner updateAddressSupplement(int ownerId,
			String newAddressSupplement) {
		Owner owner = getOwner(ownerId);
		
		owner.setAddressSupplement(newAddressSupplement);
		return owner;
	}

	@Override
	public void removeOwner(int ownerId) {
		Owner ownerToRemove = getOwner(ownerId);
		
		// Avoid concurrent modification
		Collection<Textile> textiles = new ArrayList<Textile>(ownerToRemove.getTextiles());
		for(Textile cur : textiles)
			cur.setOwner(null);
		ownerToRemove.setCustomer(null);
		
		em.remove(ownerToRemove);
	}

	@Override
	public Owner getOwner(int ownerId) {
		Owner owner = em.find(Owner.class, ownerId);
		if(owner == null)
			throw new IllegalArgumentException(String.format("Owner with ID %s not found", ownerId));
		return owner;
	}
	
	@Override
	public Collection<Textile> getTextilesOfOwner(int ownerId) {
		Owner owner = getOwner(ownerId);
		Collection<Textile> textiles = owner.getTextiles();
		// Initialize
		textiles.size();
		return textiles;
	}
}
