package de.unimuenster.pi.laundry.ejb;

import java.util.Collection;
import java.util.Date;

import javax.ejb.Remote;

import de.unimuenster.pi.laundry.jpa.CleaningOrder;
import de.unimuenster.pi.laundry.jpa.CleaningOrderPosition;
import de.unimuenster.pi.laundry.jpa.WashingProgram;

/**
 * Service class for the management of cleaning orders and their positions.
 * @author Henning Heitkoetter
 */
@Remote
public interface CleaningOrderService {
/* ============================ Cleaning Order ============================ */
	
	CleaningOrder createCleaningOrder(int customerId, Date dateOfReceipt);
	
	/**
	 * Sets the state of the Cleaning Order with the given ID to {@link CleaningOrder.State#Delivered delivered}.
	 * The order has to be in state {@link CleaningOrder.State#Finished finished}.
	 * @param cleaningOrderId ID of the order.
	 * @return The updated order.
	 * @throws IllegalStateException If the order is not {@link CleaningOrder.State#Finished finished}.
	 */
	CleaningOrder setDelivered(int cleaningOrderId);
	
	/**
	 * Sets the state of the Cleaning Order with the given ID to {@link CleaningOrder.State#Invoiced invoiced}.
	 * Sets amount of the invoice to the given value.
	 * The order has to be in state {@link CleaningOrder.State#Delivered delivered}.
	 * @param cleaningOrderId ID of the order.
	 * @param invoiceAmount Amount of the invoice.
	 * @return The updated order.
	 * @throws IllegalStateException If the order is not {@link CleaningOrder.State#Delivered delivered}.
	 */
	CleaningOrder setInvoiced(int cleaningOrderId, int invoiceAmount);
	
	/**
	 * Sets the state of the Cleaning Order with the given ID to {@link CleaningOrder.State#Paid paid}.
	 * The order has to be in state {@link CleaningOrder.State#Invoiced invoiced}.
	 * @param cleaningOrderId ID of the order.
	 * @return The updated order.
	 * @throws IllegalStateException If the order is not {@link CleaningOrder.State#Invoiced invoiced}.
	 */
	CleaningOrder setPaid(int cleaningOrderId);

	CleaningOrder getCleaningOrder(int cleaningOrderId);

/* ============================ Cleaning Order Position ============================ */
	
	/**
	 * Adds a new position to the cleaning order with the given ID. The barcode references the textile to be cleaned.
	 * The textile must not be referenced in another unfinished cleaning order position.
	 * The customer of the order has to match the customer associated with the textile.
	 * The order must be in state {@link CleaningOrder.State#Processing processing}.
	 * @param cleaningOrderId ID of the cleaning order to which the position belongs.
	 * @param barcode Barcode of the textile for which the position should be created.
	 * @param programToUse Program to use in this cleaning. If <code>null</code>, the default program
	 * of the textile will be used.
	 * @return The new position.
	 */
	CleaningOrderPosition createPosition(int cleaningOrderId, String barcode, WashingProgram programToUse);
	
	/**
	 * The current position of the textile with the given barcode proceeds from state {@link CleaningOrderPosition.State#Received received} to 
	 * {@link CleaningOrderPosition.State#Cleaning cleaning}.
	 * @param barcode Barcode of the textile whose current order position should be updated.
	 * @return The order position which has been updated.
	 * @throws IllegalStateException If the position is not in state {@link CleaningOrderPosition.State#Received received}.
	 */
	CleaningOrderPosition setCleaning(String barcode);
	
	/**
	 * The current position of the textile with the given barcode proceeds from state {@link CleaningOrderPosition.State#Cleaning cleaning} to 
	 * {@link CleaningOrderPosition.State#Cleaned cleaned}.
	 * If the position was the last of the order to be cleaned, the order is set to {@link CleaningOrder.State#Finished finished}.
	 * @param barcode Barcode of the textile whose current order position should be updated.
	 * @return The order position which has been updated.
	 * @throws IllegalStateException If the position is not in state {@link CleaningOrderPosition.State#Cleaning cleaning}.
	 */
	CleaningOrderPosition setCleaned(String barcode);
	
	Collection<CleaningOrderPosition> getPositionsOfOrder(int orderId);
}
