package de.unimuenster.pi.laundry.web;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import de.unimuenster.pi.laundry.ejb.TextileService;
import de.unimuenster.pi.laundry.jpa.Textile;
import de.unimuenster.pi.laundry.jpa.WashingProgram;

@ManagedBean
@ViewScoped
public class TextilePage {
	@EJB
	private TextileService textileService;
	
	private int textileId;
	private Textile textile;

	public void setTextileId(int textileId) {
		this.textileId = textileId;
		init();
	}

	public int getTextileId() {
		return textileId;
	}

	public Textile getTextile() {
		if(textile == null)
			textile = textileService.getTextile(getTextileId());
		return textile;
	}

	public void init() {
		textile = null;
	}
	
	public void ensureInitialized(){
		try{
			if(getTextile() != null)
				// Success
				return;
		} catch(EJBException e) {
			e.printStackTrace();
		}
		Util.redirectToRoot();
	}
	
	public WashingProgram[] getProgramValues(){
		return WashingProgram.values();
	}
	
	public void submitChanges(){
		try {
			textileService.updateTextile(getTextile());
		} catch (EJBException e) {
			Util.addErrorMessageToContext(e);
		}
	}
}
