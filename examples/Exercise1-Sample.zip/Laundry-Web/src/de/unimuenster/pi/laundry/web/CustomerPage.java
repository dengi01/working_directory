package de.unimuenster.pi.laundry.web;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import de.unimuenster.pi.laundry.ejb.CleaningOrderService;
import de.unimuenster.pi.laundry.ejb.CustomerService;
import de.unimuenster.pi.laundry.ejb.OwnerService;
import de.unimuenster.pi.laundry.jpa.CleaningOrder;
import de.unimuenster.pi.laundry.jpa.Customer;
import de.unimuenster.pi.laundry.jpa.Owner;

@ManagedBean
@ViewScoped
public class CustomerPage {
	@EJB
	private CustomerService customerService;
	@EJB
	private OwnerService ownerService;
	@EJB
	private CleaningOrderService orderService;
	
	private int customerId;
	private Customer customer;
	
	private Collection<Owner> owners;
	
	private Owner newOwner;
	
	private Collection<CleaningOrder> orders;
	
	private Date newOrderDate;
	
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
		init();
	}

	public int getCustomerId() {
		return customerId;
	}

	public Customer getCustomer() {
		if(customer == null)
			customer = customerService.getCustomer(getCustomerId());
		return customer;
	}

	public void init() {
		customer = null;
		owners = null;
		newOwner = null;
		orders = null;
		newOrderDate = null;
	}

	public void ensureInitialized() {
		try{
			if(getCustomer() != null)
				// Success
				return;
		} catch(EJBException e) {
			e.printStackTrace();
		}
		Util.redirectToRoot();
	}
	
	public void submitChanges() {
		customer = customerService.updateAddress(getCustomer().getId(), getCustomer().getAddress());
	}

	public Collection<Owner> getOwners() {
		if(owners == null)
			owners = new ArrayList<Owner>(customerService.getOwnersOfCustomer(getCustomer().getId()));
		return owners;
	}

	public Owner getNewOwner() {
		if(newOwner == null)
			newOwner = new Owner();
		return newOwner;
	}
	
	public void createNewOwner() {
		ownerService.createOwner(getNewOwner(), getCustomer().getId());
		newOwner = null;
		owners = null;
	}

	public Collection<CleaningOrder> getOrders() {
		if(orders == null)
			orders = new ArrayList<CleaningOrder>(customerService.getOrdersOfCustomer(getCustomer().getId()));
		return orders;
	}

	public Date getNewOrderDate() {
		if(newOrderDate == null)
			newOrderDate = new Date();
		return newOrderDate;
	}

	public void setNewOrderDate(Date newOrderDate) {
		this.newOrderDate = newOrderDate;
	}
	
	public String createNewOrder() {
		CleaningOrder result = orderService.createCleaningOrder(getCustomer().getId(), getNewOrderDate());
		newOrderDate = null;
		orders = null;
		
		return "/order/details.xhtml?faces-redirect=true&id=" + result.getId();
	}
}
