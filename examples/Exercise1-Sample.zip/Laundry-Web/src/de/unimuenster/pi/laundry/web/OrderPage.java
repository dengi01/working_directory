package de.unimuenster.pi.laundry.web;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.persistence.NoResultException;

import de.unimuenster.pi.laundry.ejb.CleaningOrderService;
import de.unimuenster.pi.laundry.ejb.TextileService;
import de.unimuenster.pi.laundry.jpa.CleaningOrder;
import de.unimuenster.pi.laundry.jpa.CleaningOrderPosition;
import de.unimuenster.pi.laundry.jpa.Textile;
import de.unimuenster.pi.laundry.jpa.WashingProgram;

@ManagedBean
@ViewScoped
public class OrderPage {
	private static final BigDecimal _100 = new BigDecimal(100);

	@EJB
	private CleaningOrderService orderService;
	@EJB
	private TextileService textileService;
	
	private int orderId;
	private CleaningOrder order;
	
	private Integer newInvoiceAmount;
	
	private Collection<CleaningOrderPosition> positions;
	
	private String newPositionBarcode;
	
	private Textile newPositionTextile;
	
	private boolean useDefaultProgram;
	
	private WashingProgram newPositionProgram;
	
	public void setOrderId(int orderId) {
		this.orderId = orderId;
		init();
	}

	public int getOrderId() {
		return orderId;
	}

	public CleaningOrder getOrder() {
		if(order == null)
			order = orderService.getCleaningOrder(getOrderId());
		return order;
	}

	public void init(){
		order = null;
		setNewInvoiceAmount(null);
		positions = null;
		setNewPositionBarcode(null);
		setUseDefaultProgram(true);
		setNewPositionProgram(null);
	}
	
	public void ensureInitialized(){
		try{
			if(getOrder() != null)
				// Success
				return;
		} catch(EJBException e) {
			e.printStackTrace();
		}
		Util.redirectToRoot();
	}

	public void setNewInvoiceAmount(BigDecimal invoiceAmount) {
		this.newInvoiceAmount = invoiceAmount==null?null:invoiceAmount.multiply(_100).intValue();
	}

	public BigDecimal getNewInvoiceAmount() {
		if(newInvoiceAmount == null)
			return null;
		return new BigDecimal(newInvoiceAmount).divide(_100);
	}
	
	public CleaningOrder.State getNextState() {
		CleaningOrder.State curState = getOrder().getState();
		if(curState == CleaningOrder.State.Processing || curState == CleaningOrder.State.Paid)
			return null;
		return CleaningOrder.State.values()[curState.ordinal()+1];
	}
	
	public void proceed(){
		switch(getOrder().getState()) {
		case Finished:
			order = orderService.setDelivered(getOrder().getId());
			break;
		case Delivered:
			order = orderService.setInvoiced(getOrder().getId(), newInvoiceAmount);
			setNewInvoiceAmount(null);
			break;
		case Invoiced:
			order = orderService.setPaid(getOrder().getId());
			break;
		}
	}

	public Collection<CleaningOrderPosition> getPositions() {
		if(positions == null)
			positions = new ArrayList<CleaningOrderPosition>(orderService.getPositionsOfOrder(getOrder().getId()));
		return positions;
	}
	
	public void proceedPosition(CleaningOrderPosition position) {
		switch(position.getState()){
		case Received:
			orderService.setCleaning(position.getTextile().getBarcode());
			break;
		case Cleaning:
			orderService.setCleaned(position.getTextile().getBarcode());
			break;
		}
		init();
	}
	
	public String getNewPositionBarcode() {
		return newPositionBarcode;
	}

	public void setNewPositionBarcode(String newPositionBarcode) {
		this.newPositionBarcode = newPositionBarcode;
		newPositionTextile = null;
	}
	
	public Textile getNewPositionTextile() {
		if(newPositionTextile == null) {
			try {
				newPositionTextile = textileService.getTextile(getNewPositionBarcode());
			} catch (EJBException e) {
				if(!(e.getCausedByException() instanceof NoResultException))
					throw e;
			}
		}
		return newPositionTextile;
	}
	
	public void setUseDefaultProgram(boolean useDefaultProgram) {
		this.useDefaultProgram = useDefaultProgram;
	}

	public boolean isUseDefaultProgram() {
		return useDefaultProgram;
	}

	public WashingProgram[] getProgramValues(){
		return WashingProgram.values();
	}

	public void setNewPositionProgram(WashingProgram newPositionProgram) {
		this.newPositionProgram = newPositionProgram;
	}

	public WashingProgram getNewPositionProgram() {
		if(newPositionProgram == null) {
			if(getNewPositionTextile() != null)
				return getNewPositionTextile().getDefaultProgram();
		}
		return newPositionProgram;
	}

	public void createNewPosition() {
		try {
			orderService.createPosition(getOrder().getId(), getNewPositionBarcode(), getNewPositionProgram());
		} catch (EJBException e) {
			Util.addErrorMessageToContext(e);
		}
		setNewPositionBarcode(null);
		setNewPositionProgram(null);
		positions = null;
	}
}
