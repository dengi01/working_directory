package de.unimuenster.pi.laundry.web;

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import de.unimuenster.pi.laundry.ejb.SearchService;

@ManagedBean
@ViewScoped
public class Navigation {
	@EJB
	private SearchService searchService;
	
	private String searchText;

	private List<?> result;
	
	private String navigateTo;
	
	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	
	public void customerSearch(){
		result = searchService.searchForCustomer(getSearchText());
		navigateTo = "customerDetails";
	}
	
	public void ownerSearch(){
		result = searchService.searchForOwner(getSearchText());
		navigateTo = "ownerDetails";
	}
	
	public void textileSearch(){
		result = searchService.searchForTextile(getSearchText());
		navigateTo = "textileDetails";
	}

	public List<?> getResult() {
		return result;
	}
	
	public String getNavigateTo(){
		return navigateTo;
	}
}
