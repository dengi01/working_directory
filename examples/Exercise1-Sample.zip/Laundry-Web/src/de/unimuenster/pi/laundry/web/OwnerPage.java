package de.unimuenster.pi.laundry.web;

import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import de.unimuenster.pi.laundry.ejb.OwnerService;
import de.unimuenster.pi.laundry.ejb.TextileService;
import de.unimuenster.pi.laundry.jpa.Owner;
import de.unimuenster.pi.laundry.jpa.Textile;
import de.unimuenster.pi.laundry.jpa.WashingProgram;

@ManagedBean
@ViewScoped
public class OwnerPage {
	@EJB
	private OwnerService ownerService;
	@EJB
	private TextileService textileService;
	
	private int ownerId;
	private Owner owner;
	
	private Collection<Textile> textiles;
	
	private Textile newTextile;

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
		init();
	}

	public int getOwnerId() {
		return ownerId;
	}

	public Owner getOwner() {
		if(owner == null)
			owner = ownerService.getOwner(getOwnerId());
		return owner;
	}

	public void init() {
		owner = null;
		textiles = null;
		newTextile = null;
	}
	
	public void ensureInitialized(){
		try{
			if(getOwner() != null)
				// Success
				return;
		} catch(EJBException e) {
			e.printStackTrace();
		}
		Util.redirectToRoot();
	}
	
	public void submitChanges() {
		owner = ownerService.updateAddressSupplement(getOwner().getId(), getOwner().getAddressSupplement());
	}
	
	public String deleteOwner() {
		ownerService.removeOwner(getOwner().getId());
		return "/customer/details.xhtml?faces-redirect=true&id=" + getOwner().getCustomer().getId();
	}

	public Collection<Textile> getTextiles() {
		if(textiles == null)
			textiles = new ArrayList<Textile>(ownerService.getTextilesOfOwner(getOwner().getId()));
		return textiles;
	}
	
	public WashingProgram[] getProgramValues(){
		return WashingProgram.values();
	}
	
	public Textile getNewTextile(){
		if(newTextile == null)
			newTextile = new Textile();
		return newTextile;
	}
	
	public void createNewTextile() {
		try {
			textileService.createTextile(getNewTextile(), getOwner().getId());
		} catch (EJBException e) {
			Util.addErrorMessageToContext(e);
		}
		newTextile = null;
		textiles = null;
	}
}
