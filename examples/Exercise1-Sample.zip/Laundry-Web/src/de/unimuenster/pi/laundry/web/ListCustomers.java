package de.unimuenster.pi.laundry.web;

import java.util.Collection;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;

import de.unimuenster.pi.laundry.ejb.CustomerService;
import de.unimuenster.pi.laundry.jpa.Customer;

@ManagedBean
public class ListCustomers {
	@EJB
	private CustomerService customerService;
	
	private Collection<Customer> customers;

	public Collection<Customer> getCustomers() {
		if(customers == null)
			customers = customerService.getAllCustomers();
		return customers;
	}
}
