package de.unimuenster.pi.laundry.web;


import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;

import de.unimuenster.pi.laundry.ejb.CustomerService;
import de.unimuenster.pi.laundry.jpa.Customer;

@ManagedBean
public class CreateCustomer {
	private Customer customer = new Customer();
	private Customer lastCustomer;
	
	private boolean batch;
	
	private String errorMessage;
	
	@EJB
	private CustomerService customerService;

	public Customer getCustomer() {
		return customer;
	}

	public boolean isBatch() {
		return batch;
	}

	public void setBatch(boolean batch) {
		this.batch = batch;
	}
	
	public String persist() {
		// Action
		try{
			lastCustomer = customerService.createCustomer(customer);
			customer = null;
			errorMessage = null;
		}
		catch(EJBException e){
			errorMessage = "Customer not created: " + Util.getConstraintMessage(e);
		}
		
		// Navigation
		if(isBatch() || isError())
			return null;
		else
			return "customerList";
	}

	public boolean isError() {
		return errorMessage != null;
	}
	
	public boolean isSuccess() {
		return lastCustomer != null;
	}
	
	public String getLastResult(){
		if(lastCustomer != null)
			return "Customer created: " + lastCustomer.toString();
		return errorMessage!=null?errorMessage:"";
	}
}
