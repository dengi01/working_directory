package de.unimuenster.pi.laundry.jpa;

/**
 * Enumeration of possible washing programs
 * 
 * @author Henning Heitkoetter
 */
public enum WashingProgram {
	Normal, Gentle, VeryGentle
}
