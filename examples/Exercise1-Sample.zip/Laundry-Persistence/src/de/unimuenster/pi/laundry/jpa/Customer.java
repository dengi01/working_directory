package de.unimuenster.pi.laundry.jpa;

import java.io.Serializable;
import java.lang.String;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import static javax.persistence.CascadeType.ALL;
import static javax.persistence.CascadeType.PERSIST;
import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.CascadeType.REFRESH;
import static javax.persistence.CascadeType.DETACH;

/**
 * Large customer (bulk buyer).
 * 
 * @author Henning Heitkoetter
 */
@Entity
public class Customer implements Serializable {
	private static final long serialVersionUID = -1033399597852244527L;

	@Id
	@GeneratedValue
	private int id;

	@NotNull(message="Name required")
	@Size(min=1, message="Name required")
	@Column(unique = true)
	private String name;
	private String address;

	@OneToMany(mappedBy = "customer", cascade = ALL)
	private Collection<Owner> owners = new LinkedList<Owner>();
	@OneToMany(mappedBy = "customer", cascade = { PERSIST, MERGE, REFRESH, DETACH })
	private Collection<CleaningOrder> orders = new LinkedList<CleaningOrder>();

	public Customer() {
		super();
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}

	protected void setOwners(Collection<Owner> owners) {
		this.owners = owners;
	}

	public Collection<Owner> getOwners() {
		return Collections.unmodifiableCollection(owners);
	}
	
	protected void addOwner(Owner owner) {
		owners.add(owner);
	}
	
	protected void removeOwner(Owner owner) {
		owners.remove(owner);
	}

	protected void setOrders(Collection<CleaningOrder> orders) {
		this.orders = orders;
	}

	public Collection<CleaningOrder> getOrders() {
		return Collections.unmodifiableCollection(orders);
	}
	
	protected void addOrder(CleaningOrder order) {
		orders.add(order);
	}
	
	protected void removeOrder(CleaningOrder order) {
		orders.remove(order);
	}

	@Override
	public String toString() {
		return getName();
	}
}
