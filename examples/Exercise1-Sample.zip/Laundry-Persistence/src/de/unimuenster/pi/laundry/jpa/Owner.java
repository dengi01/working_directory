package de.unimuenster.pi.laundry.jpa;

import de.unimuenster.pi.laundry.jpa.Customer;
import java.io.Serializable;
import java.lang.String;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import static javax.persistence.CascadeType.PERSIST;
import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.CascadeType.REFRESH;
import static javax.persistence.CascadeType.DETACH;

/**
 * Owner of textiles associated with a customer.
 * 
 * @author Henning Heitkoetter
 */
@Entity
public class Owner implements Serializable {
	private static final long serialVersionUID = -5324243646299460336L;

	@Id
	@GeneratedValue
	private int id;
	
	@NotNull(message="Name required")
	@Size(min=1, message="Name required")
	private String name;
	private String addressSupplement;
	
	@ManyToOne
	@NotNull
	private Customer customer;
	@OneToMany(mappedBy = "owner", cascade = { PERSIST, MERGE, REFRESH, DETACH })
	private Collection<Textile> textiles = new LinkedList<Textile>();

	public Owner() {
		super();
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public void setAddressSupplement(String addressSupplement) {
		this.addressSupplement = addressSupplement;
	}

	public String getAddressSupplement() {
		return this.addressSupplement;
	}

	public void setCustomer(Customer customer) {
		if(this.customer != null)
			this.customer.removeOwner(this);
		this.customer = customer;
		if(customer != null)
			customer.addOwner(this);
	}

	public Customer getCustomer() {
		return this.customer;
	}

	protected void setTextiles(Collection<Textile> textiles) {
		this.textiles = textiles;
	}

	public Collection<Textile> getTextiles() {
		return Collections.unmodifiableCollection(textiles);
	}
	
	protected void addTextile(Textile textile) {
		textiles.add(textile);
	}
	
	protected void removeTextile(Textile textile) {
		textiles.remove(textile);
	}

	@Override
	public String toString() {
		return String.format("%s (Customer: %s)", getName(), getCustomer());
	}
}
