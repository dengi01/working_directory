package de.unimuenster.pi.laundry.jpa;

import de.unimuenster.pi.laundry.jpa.CleaningOrder;
import de.unimuenster.pi.laundry.jpa.Textile;
import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 * A position of a cleaning order, representing one textile as part of an order
 * with the chosen washing program.
 * 
 * @author Henning Heitkoetter
 */
@Entity
public class CleaningOrderPosition implements Serializable {
	private static final long serialVersionUID = 8445047322652765108L;

	public enum State {
		Received, Cleaning, Cleaned
	}

	@Id
	@GeneratedValue
	private int id;
	
	@NotNull
	private State state = State.Received;
	@NotNull
	private WashingProgram programToUse;
	
	@ManyToOne
	@NotNull
	private CleaningOrder order;
	@ManyToOne
	@NotNull
	private Textile textile;

	public CleaningOrderPosition() {
		super();
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}

	public void setState(State state) {
		this.state = state;
	}

	public State getState() {
		return state;
	}

	public void setOrder(CleaningOrder order) {
		if(this.order != null)
			this.order.removePosition(this);
		this.order = order;
		if(order != null)
			order.addPosition(this);
	}

	public CleaningOrder getOrder() {
		return this.order;
	}

	public void setTextile(Textile textile) {
		// no opposite reference (Textile.currentOrder is separate)
		this.textile = textile;
	}

	public Textile getTextile() {
		return this.textile;
	}

	public void setProgramToUse(WashingProgram programToUse) {
		this.programToUse = programToUse;
	}

	public WashingProgram getProgramToUse() {
		return programToUse;
	}

}
