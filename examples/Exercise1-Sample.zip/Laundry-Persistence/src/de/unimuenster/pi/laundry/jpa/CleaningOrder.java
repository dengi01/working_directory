package de.unimuenster.pi.laundry.jpa;

import de.unimuenster.pi.laundry.jpa.Customer;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import static javax.persistence.CascadeType.ALL;

/**
 * A cleaning order by one customer consisting of several positions.
 * @author Henning Heitkoetter
 */
@Entity
public class CleaningOrder implements Serializable {
	private static final long serialVersionUID = 6915114861799073846L;

	public enum State {
		Processing, Finished, Delivered, Invoiced, Paid
	}

	@Id
	@GeneratedValue
	private int id;
	
	@NotNull
	private Date dateOfReceipt;
	@NotNull
	private State state = State.Processing;
	@Min(0)
	private int invoiceAmount;
	
	@ManyToOne
	@NotNull
	private Customer customer;
	@OneToMany(mappedBy = "order", cascade = ALL)
	private Collection<CleaningOrderPosition> positions;

	public CleaningOrder() {
		super();
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}

	public void setDateOfReceipt(Date dateOfReceipt) {
		this.dateOfReceipt = dateOfReceipt;
	}

	public Date getDateOfReceipt() {
		return this.dateOfReceipt;
	}

	public void setState(State state) {
		this.state = state;
	}

	public State getState() {
		return state;
	}

	public void setInvoiceAmount(int invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public int getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setCustomer(Customer customer) {
		if(this.customer != null)
			this.customer.removeOrder(this);
		this.customer = customer;
		if(customer != null)
			customer.addOrder(this);
	}

	public Customer getCustomer() {
		return this.customer;
	}

	protected void setPositions(Collection<CleaningOrderPosition> positions) {
		this.positions = positions;
	}

	public Collection<CleaningOrderPosition> getPositions() {
		return Collections.unmodifiableCollection(positions);
	}
	
	protected void addPosition(CleaningOrderPosition position) {
		positions.add(position);
	}
	
	protected void removePosition(CleaningOrderPosition position) {
		positions.remove(position);
	}

}
