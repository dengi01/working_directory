package de.unimuenster.pi.laundry.jpa;

import java.io.Serializable;
import java.lang.String;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * A textile piece like clothing or linen.
 * 
 * @author Henning Heitkoetter
 */
@Entity
public class Textile implements Serializable {
	private static final long serialVersionUID = 2903484805823809076L;

	@Id
	@GeneratedValue
	private int id;
	
	@NotNull(message="Barcode required")
	@Pattern(regexp="[0-9A-Za-z\\-]*",message="Barcode - illegal character (only digits, letters or - allowed)")
	@Size(min=10, message="Barcode too short (at least 10 characters required)")
	@Column(unique = true)
	private String barcode;
	private String description;
	@NotNull
	private WashingProgram defaultProgram = WashingProgram.Normal;
	
	@ManyToOne
	// may be null
	private Owner owner;
	@OneToOne
	// may be null
	private CleaningOrderPosition currentOrder;

	public Textile() {
		super();
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getBarcode() {
		return this.barcode;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDefaultProgram(WashingProgram defaultProgram) {
		this.defaultProgram = defaultProgram;
	}

	public WashingProgram getDefaultProgram() {
		return defaultProgram;
	}

	public void setOwner(Owner owner) {
		if(this.owner != null)
			this.owner.removeTextile(this);
		this.owner = owner;
		if(owner != null)
			owner.addTextile(this);
	}

	public Owner getOwner() {
		return owner;
	}

	public void setCurrentOrder(CleaningOrderPosition currentOrder) {
		this.currentOrder = currentOrder;
	}

	public CleaningOrderPosition getCurrentOrder() {
		return currentOrder;
	}

	@Override
	public String toString() {
		return (getBarcode()!=null?getBarcode():String.valueOf(getId())) + 
				(getDescription()!=null?" ("+getDescription()+")":"");
	}
}
